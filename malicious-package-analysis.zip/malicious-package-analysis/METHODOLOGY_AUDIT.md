# Methodology audit

Status labels: **Confirmed** (checked by computation or in the text), **Possible** (plausible, cannot be settled with the data at hand), **Improvement**, **Extension**. "Reproduced data" means `data/real/`, the conversion of this project's earlier pipeline outputs; it is not the paper's original files.

## 1. What the paper proposes

An evaluation framework, not a detector. It normalizes outputs of existing tools (GuardDog, Bandit, an OSV malicious-package feed, OSV-Scanner as a negative control, GuardDog capability output) to package-level signals, labels 122 malicious packages with behaviors from a 12-category taxonomy, and reports package-level metrics with seeded bootstrap intervals (2,000 resamples, seed 42), behavior-level detection rates with N/A for inapplicable tool and behavior pairs, pairwise union recall against union FPR, and a duplicate sensitivity run (122 to 74 malicious, 103 benign). Its stated claim is limited: results describe a curated benchmark and do not establish ecosystem-wide performance or that chain-aware detection reduces false positives.

## 2. Implementable directly from the paper

Every metric and definition (eq. 1 to 9), the taxonomy, the applicability rule (Bandit B4, B6, B7, B8), N/A handling, pairwise gain and Jaccard, duplicate sensitivity given cluster ids, provenance fields. All are implemented.

## 3. Needs the original data

The 130-sample DataDog draw (seed 42) and its hashes, the raw outputs of each tool with versions and timestamps, the behavior labels (and any manual validation record), the 103 benign package versions, the cluster assignments behind the 74-package subset, the OSV feed snapshot. Without them the numerical experiment cannot be reproduced exactly from the PDF alone. Section 8 lists them.

## 4. Weaknesses that affect validity

| # | Finding | Status | Evidence / impact |
|---|---|---|---|
| 1 | Reported arithmetic is internally consistent. F1 from reported precision and recall, and precision implied by recall, FPR and 122/103, agree within rounding for all five signals; GuardDog dedup recall 0.959 = 71/74; abstract fractions (7/22, 2/5, 56/62, 36/43) match. | Confirmed (no defect) | `paper_consistency.csv`, checks I01 to I28; I29 and I30 are notes |
| 2 | On the reproduced data every point estimate, behavior rate, pair union and dedup count matches the paper. Six bootstrap endpoints differ by 0.004 to 0.007 (e.g. OSV malicious recall CI 0.704 to 0.852 reported, 0.697 to 0.847 here). The paper does not say whether resampling is stratified or which RNG was used. | Confirmed difference, Clarification | `paper_consistency.csv` status `minor_difference` |
| 3 | The manifest exclusion rule (8 of 130 dropped because no behavior label could be assigned) conditions recall on annotator success. Counting those 8 as malicious: GuardDog recall 0.975 to 0.923 (120/130), Bandit 0.844 to 0.808, OSV malicious 0.779 to 0.754. The excluded packages are probably the hardest to read statically. | Confirmed on reproduced data | `package_metrics.csv`, `analysis=including_excluded` |
| 4 | Package-level bootstrap treats related samples as independent. The largest campaign has 34 of 122 malicious packages (27.9%); 74 clusters in total. A cluster bootstrap widens intervals: Bandit recall 0.777 to 0.906 becomes 0.712 to 0.923, OSV malicious recall 0.697 to 0.847 becomes 0.662 to 0.851, GuardDog recall 0.944 to 1.000 becomes 0.933 to 1.000. Rankings by point estimate do not change. | Confirmed on reproduced data | `bootstrap_intervals.csv`, `method=cluster` |
| 5 | Degenerate intervals. OSV malicious FPR [0, 0] and capability recall [1, 1] come from percentile bootstrap at a boundary. With 0 false positives in 103, an exact 95% upper bound is about 0.035 (1 - 0.025^(1/103)); the interval [0, 0] understates uncertainty. | Confirmed (statistical) | `degenerate_interval` flag |
| 6 | Precision and F1 depend on class balance. Deduplication removes only malicious packages, so GuardDog precision falls 0.788 to 0.689 and F1 0.872 to 0.802 with FPR unchanged at 0.311. Comparisons of precision across the two sets measure prevalence, not the detector. | Confirmed | `duplicate_sensitivity.csv` |
| 7 | Label and detector circularity. Behavior labels come from one regex annotator whose pattern families resemble GuardDog's rule families; no second annotator, no kappa. High GuardDog rates for B5, B7, B9 may partly reflect shared vocabulary. | Possible | cannot be tested without independent labels |
| 8 | Sampling bias. Malicious samples were largely discovered with GuardDog (stated by the paper). The OSV malicious feed is also a report database; overlap in provenance with the DataDog set is unchecked. | Confirmed (GuardDog), Possible (OSV) | threat to validity, not fixable in code |
| 9 | Mapping choices drive behavior rates. The Bandit map sends B404 (import subprocess) to B4, so "command execution" can be credited for an import. Bandit B4 = 78/79 is therefore weak evidence. Bandit rule ids were not retained in the reproduced data, so the share driven by import-only findings cannot be measured. | Confirmed (mapping), Possible (effect size) | `config/behavior_mapping.yaml` |
| 10 | Tool-count wording. The abstract lists five "tools"; there are four tools and five signals (GuardDog supplies two). The text calls OSV-Scanner a vulnerability scanner but the reproduced data used a custom advisory-database matcher. | Clarification | DEVIATIONS.md |
| 11 | GuardDog capability output (recall 1.000, FPR 0.883) is a package-level signal; including it in "highest recall" statements is misleading. The paper says it is excluded from behavior detection; this pipeline enforces that through `behavior_categories`. | Clarification | config |
| 12 | Reference [7] (arXiv:2603.27549) is cited as "Understanding NPM Malicious Package Detection: A Benchmark-Driven Empirical Analysis"; a web search for that identifier returned the title "How Effective Are NPM Malicious Package Detectors? A Large-Scale Empirical Study". Authors, version and title should be checked against the arXiv record. | Possible | verify before submission |

## 5. Corrections that keep the research question

Report the exclusion sensitivity next to the primary table (done). Report cluster-aware intervals next to package-level ones (done). Report FPR and recall rather than precision when comparing sets with different prevalence (kept; precision is shown with the caveat). Replace aggregate Bandit and GuardDog behavior credit by rule-level credit, and publish the mapping with a review column. Add a second annotator on a stratified subset (at least all of B2, B10, B11, B12 plus a random 30 of the rest) and report Cohen's kappa per behavior. Retain raw tool output, versions and timestamps in the released artifact.

## 6. Novelty assessment

Closest prior work found by search (titles only; I did not read the papers): "A Benchmark Comparison of Python Malware Detection Approaches" (arXiv:2209.13288), "Bad Snakes: Understanding and Improving Python Package Index Malware Scanning" (ICSE 2023), "Killing Two Birds with One Stone: Malicious Package Detection in NPM and PyPI using a Single Model of Malicious Behavior Sequence" (arXiv:2309.02637), and the Guo et al. NPM benchmark the paper already cites. The search was shallow and cannot support a novelty claim.

What the paper contributes beyond restating those works, if it holds up under a proper literature check, is narrow: a behavior-indexed, applicability-aware reporting convention (N/A not 0, package-level signals kept apart from behavior evidence) applied to open-source PyPI tools, with duplicate and exclusion sensitivity. The strongest defensible claim today is methodological: tools of different kinds should not be ranked on one leaderboard. The capability versus intent hypothesis is not tested by the current data. A paired chain-versus-isolated-capability experiment (Extension B) is the one addition that could be a real empirical contribution, and only with independent annotation.

## 7. Extensions ranked (feasibility first, then contribution)

| Rank | Extension | Question / hypothesis | Data needed | Design and metrics | Confounders | Status |
|---|---|---|---|---|---|---|
| 1 | C. Cluster-aware robustness | Do rankings, blind spots and complementarity survive treating campaigns as units? H: ranking holds, intervals widen. | cluster ids (have) | cluster bootstrap, deduplicated rerun | clustering method (exact normalized-code hash under-merges) | **Implemented** (`bootstrap method=cluster`, `deduplicated` analyses). Result: rankings unchanged, intervals wider. |
| 2 | A. Evidence-calibrated attribution | How much tool evidence maps to a behavior, and how reliable is the mapping? | rule-level findings, a second annotator | mapping coverage, unresolved rate, kappa | single annotator | **Partly implemented**: unmapped findings are reported (88 GuardDog findings map to no behavior in the reproduced data). Agreement needs a second annotator: blocked. |
| 3 | Exclusion sensitivity (new, from audit item 3) | How much does the annotator-success filter inflate recall? | manifest exclusions with tool runs (have) | rescoring with excluded packages | excluded packages may be empty or placeholder artifacts | **Implemented** (`including_excluded`). |
| 4 | B. Capability versus intent | Does requiring a chain (e.g. read secret, encode, send) cut false positives at fixed recall? H: yes at recall target 0.95. | independently annotated benign and malicious packages, a predefined chain definition and FP budget | paired comparison: isolated-capability rule vs chain rule on the same packages, FPR at recall target, McNemar test | annotator bias, benign selection | Not implemented; needs data and annotation protocol. Probes from the earlier project (10 evasion variants) are a seed, not a substitute. |
| 5 | E. Operating point and FP cost | FPR at a fixed budget or recall target | scores or ordered evidence categories | operating curves where scores exist | binary outputs give no curve | Not implemented; current tools are binary. |
| 6 | D. Drift | Do tool versions change results on a fixed corpus? | repeated runs with versions and rule sets | per-package flip counts | corpus must stay fixed | Blocked: no repeated runs; the manifest records versions to make this possible. |

## 8. External resources required to reproduce the paper's numbers exactly

The original 130-package sample list and artifact hashes; raw JSON from each tool run with tool version, rule-set version and timestamp; the OSV malicious feed and advisory database snapshot (commit ids); the Bandit per-test findings; the 103 benign package versions and wheels; the behavior annotation files and any manual validation notes; the family cluster assignment behind the 74-package subset; for the OpenSSF extension, the Package Analysis result JSON for each package.

## 9. Questions that block work

None. Everything above ran on available data; the items in section 8 only affect exactness of reproduction.
