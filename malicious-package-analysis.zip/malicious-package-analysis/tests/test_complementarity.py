import copy

import pytest

from package_analysis.complementarity import jaccard, pairwise_rows


def _pairs(ds, pids=None):
    rows = pairwise_rows(ds, pids or sorted(ds.included))
    return {(r["signal_a"], r["signal_b"]): r for r in rows}


def test_pair_guarddog_bandit_hand_values(ds):
    r = _pairs(ds)[("guarddog", "bandit")]
    assert r["status"] == "ok"
    assert (r["n_malicious"], r["n_benign"]) == (5, 4)             # b5 dropped: bandit run failed
    assert r["recall_union"] == pytest.approx(1.0)
    assert r["recall_gain"] == pytest.approx(0.4)
    assert r["fpr_a"] == pytest.approx(0.25) and r["fpr_b"] == pytest.approx(0.5) and r["fpr_union"] == pytest.approx(0.5)
    assert r["fpr_increase_over_a"] == pytest.approx(0.25)
    assert r["jaccard_positive_sets"] == pytest.approx(2 / 7)
    assert (r["tp_both"], r["tp_unique_a"], r["tp_unique_b"]) == (1, 2, 2)
    assert (r["fp_both"], r["fp_unique_a"], r["fp_unique_b"]) == (1, 0, 1)


def test_union_with_zero_fp_signal_adds_no_fp(ds):
    r = _pairs(ds)[("guarddog", "osv_malicious")]
    assert r["fpr_union"] == pytest.approx(r["fpr_a"])
    assert r["recall_union"] == pytest.approx(0.8)                 # m1,m2,m3 or m1,m2,m4 -> m1..m4
    assert r["recall_gain"] == pytest.approx(0.2)


def test_excluded_signals_not_paired(ds):
    pairs = _pairs(ds)
    assert not any("osv_vulnerability" in k or "guarddog_capability" in k for k in pairs)


def test_unavailable_pair_when_signal_has_no_data(ds):
    d2 = copy.copy(ds)
    d2.runs = {k: v for k, v in ds.runs.items() if k[1] != "osv_malicious_feed"}
    rows = pairwise_rows(d2, sorted(ds.included))
    r = next(x for x in rows if x["signal_b"] == "osv_malicious" and x["signal_a"] == "guarddog")
    assert r["status"] == "unavailable" and r.get("recall_union") is None


def test_jaccard_edge_cases():
    assert jaccard(set(), set()) is None
    assert jaccard({1}, set()) == 0.0
    assert jaccard({1, 2}, {2, 3}) == pytest.approx(1 / 3)
    assert jaccard({1, 2}, {1, 2}) == 1.0
