import pytest

from package_analysis.behavior_coverage import coverage_rows


@pytest.fixture(scope="module")
def cov(ds):
    rows = coverage_rows(ds, sorted(ds.included))
    return {(r["signal"], r["behavior_id"]): r for r in rows}


def test_b4_denominator_and_detections(cov):
    # positives: m1, m3, m5. GuardDog threat evidence only for m1 (m3's spawn rule is capability-category).
    g = cov[("guarddog", "B4")]
    assert (g["n_confirmed_positive"], g["n_evaluated"], g["n_detected"], g["n_missed"]) == (3, 3, 1, 2)
    b = cov[("bandit", "B4")]
    assert (b["n_evaluated"], b["n_detected"]) == (3, 2)          # m1, m3 detected; m5 only had B8 evidence
    u = cov[("union", "B4")]
    assert (u["n_evaluated"], u["n_detected"]) == (3, 2)


def test_not_applicable_is_na_not_zero(cov):
    r = cov[("bandit", "B1")]
    assert r["applicability"] == "not_applicable" and r["status"] == "N/A"
    assert r.get("detection_rate") is None


def test_capability_and_feed_signals_never_appear(cov):
    assert not any(s in ("osv_malicious", "osv_vulnerability", "guarddog_capability") for s, _ in cov)


def test_unknown_annotation_is_counted_separately_and_not_scored(cov):
    r = cov[("guarddog", "B8")]
    assert r["n_unknown_annotation"] == 1 and r["n_confirmed_positive"] == 0
    assert r["n_evaluated"] == 0 and r["detection_rate"] is None and r["status"] == "no_evaluable_instances"


def test_confirmed_negative_is_not_an_instance(cov):
    assert cov[("guarddog", "B12")]["n_confirmed_positive"] == 0


def test_union_with_single_applicable_tool_is_flagged(cov):
    u = cov[("union", "B5")]
    assert "single applicable tool" in u["note"]
    assert (u["n_detected"], u["n_evaluated"]) == (1, 1)


def test_union_combines_tools(cov):
    # B7: m2 detected by GuardDog (obfuscation rule), bandit has no B7 evidence on m2
    assert (cov[("guarddog", "B7")]["n_detected"], cov[("bandit", "B7")]["n_detected"]) == (1, 0)
    assert cov[("union", "B7")]["n_detected"] == 1


def test_low_sample_status(cov):
    assert cov[("guarddog", "B5")]["status"] == "very_low_sample"      # n = 1 < 3
    assert cov[("guarddog", "B4")]["status"] == "low_sample"           # n = 3 < 10


def test_unmapped_behavior_not_credited(cov):
    # m4 also has capability-filesystem-delete (maps to nothing); B2 comes from the threat env-read rule
    assert cov[("guarddog", "B2")]["n_detected"] == 1
