import math

import numpy as np
import pytest

from package_analysis.bootstrap import bootstrap_rows
from package_analysis.metrics import evaluate


def _point(ds, pids):
    return {s: evaluate(ds, s, pids) for s in ds.signals if ds.signal_has_data(s)}


def test_same_seed_is_deterministic(ds):
    pids = sorted(ds.included)
    a = bootstrap_rows(ds, pids, _point(ds, pids), n_boot=300, seed=42)
    b = bootstrap_rows(ds, pids, _point(ds, pids), n_boot=300, seed=42)
    assert a == b


def test_different_seed_changes_intervals(ds):
    pids = sorted(ds.included)
    a = bootstrap_rows(ds, pids, _point(ds, pids), n_boot=300, seed=42)
    b = bootstrap_rows(ds, pids, _point(ds, pids), n_boot=300, seed=7)
    assert a != b


def test_interval_ordering_and_counts(ds):
    pids = sorted(ds.included)
    rows = bootstrap_rows(ds, pids, _point(ds, pids), n_boot=300, seed=42)
    for r in rows:
        assert r["n_resamples"] == 300 and r["seed"] == 42
        assert r["n_valid"] <= 300
        if r["ci_low"] is not None:
            assert r["ci_low"] <= r["ci_high"]
            assert 0.0 <= r["ci_low"] and r["ci_high"] <= 1.0


def test_zero_denominator_replicates_are_omitted_and_counted(ds):
    # Only 10 packages: many replicates draw no benign package, so FPR is undefined there.
    pids = sorted(ds.included)
    rows = bootstrap_rows(ds, pids, _point(ds, pids), n_boot=2000, seed=42)
    fpr = next(r for r in rows if r["signal"] == "guarddog" and r["metric"] == "fpr")
    rec = next(r for r in rows if r["signal"] == "guarddog" and r["metric"] == "recall")
    assert fpr["n_valid"] <= 2000 and rec["n_valid"] <= 2000
    # probability of no benign among 10 draws at p=0.5 is about 0.1%, so valid counts are high but not forced equal
    assert fpr["n_valid"] >= 1900


def test_bootstrap_matches_manual_resample_for_one_replicate(ds):
    """Replicate b of the vectorized code equals a manual recount using the same draws."""
    pids = sorted(ds.included)
    n = len(pids)
    rng = np.random.default_rng(42)
    idx = rng.integers(0, n, size=(1, n))[0]
    truth = [ds.truth(pids[i]) for i in idx]
    pred = [ds.verdict("osv_malicious", pids[i]) for i in idx]
    tp = sum(1 for t, p in zip(truth, pred) if t and p)
    fn = sum(1 for t, p in zip(truth, pred) if t and not p)
    manual = None if tp + fn == 0 else tp / (tp + fn)
    rows = bootstrap_rows(ds, pids, {"osv_malicious": evaluate(ds, "osv_malicious", pids)}, n_boot=1, seed=42)
    r = next(x for x in rows if x["metric"] == "recall")
    if manual is None:
        assert r["n_valid"] == 0
    else:
        assert r["ci_low"] == pytest.approx(manual) and r["ci_high"] == pytest.approx(manual)


def test_cluster_method_resamples_clusters(ds):
    pids = sorted(ds.included)
    rows = bootstrap_rows(ds, pids, _point(ds, pids), method="cluster", n_boot=300, seed=42)
    units = {r["n_units"] for r in rows}
    # clusters: c1, c2, c3 plus 5 singleton benign packages = 8 units (m6 excluded)
    assert units == {8}
    assert all(r["method"] == "cluster" for r in rows)


def test_unknown_method_rejected(ds):
    with pytest.raises(ValueError):
        bootstrap_rows(ds, sorted(ds.included), {}, method="nope")
