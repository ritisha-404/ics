from pathlib import Path

import pytest

from package_analysis.normalize import load_dataset

FIX = Path(__file__).parent / "fixtures"
FIXTURE_CFG = FIX / "experiment.fixture.yaml"
ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="session")
def ds():
    return load_dataset(FIXTURE_CFG)


@pytest.fixture
def copy_fixture(tmp_path):
    """Copy the synthetic fixture so a test can corrupt it."""
    import shutil
    dst = tmp_path / "fx"
    shutil.copytree(FIX, dst)
    cfg = dst / "experiment.fixture.yaml"
    cfg.write_text(cfg.read_text().replace("../../config/", str(ROOT / "config") + "/"))
    return cfg
