# Synthetic fixture (NOT empirical data)

Every row is marked `data_origin=synthetic` and `SYNTHETIC`. The fixture exists only to test code.
Hand-worked expectations (10 included packages: m1..m5 malicious, b1..b5 benign; m6 excluded):

| signal | TP | FP | TN | FN | unknown | precision | recall | F1 | FPR |
|---|---|---|---|---|---|---|---|---|---|
| guarddog (threat) | 3 (m1,m2,m4) | 1 (b1) | 4 | 2 (m3,m5) | 0 | 0.75 | 0.6 | 0.6667 | 0.2 |
| bandit | 3 (m1,m3,m5) | 2 (b1,b2) | 2 | 2 (m2,m4) | 1 (b5 run failed) | 0.6 | 0.6 | 0.6 | 0.5 |
| osv_malicious | 3 (m1,m2,m3) | 0 | 5 | 2 | 0 | 1.0 | 0.6 | 0.75 | 0.0 |
| osv_vulnerability | 0 | 1 (b3) | 4 | 5 | 0 | 0.0 | 0.0 | 0.0 | 0.2 |
| guarddog_capability | 5 | 3 (b1,b2,b3) | 2 | 0 | 0 | 0.625 | 1.0 | 0.7692 | 0.6 |

Pair guarddog+bandit (b5 dropped, bandit unknown): union recall 1.0, gain 0.4, Jaccard 2/7.
Dedup (representatives m1, m4, m5): 3 malicious + 5 benign.
