import pytest

from package_analysis.deduplication import (cluster_directory, duplicate_rows, normalized_code_hash,
                                            select_representatives)


def test_representatives_are_deterministic_and_smallest_id(ds):
    keep, removed = select_representatives(ds)
    assert keep == sorted(["m1", "m4", "m5", "b1", "b2", "b3", "b4", "b5"])
    assert {r["package_id"] for r in removed} == {"m2", "m3"}
    assert all(r["representative"] == "m1" for r in removed)


def test_duplicate_rows_report_composition_and_metric_changes(ds):
    primary = sorted(ds.included)
    keep, removed = select_representatives(ds)
    rows = duplicate_rows(ds, primary, keep, removed)
    comp = {r["key"]: r for r in rows if r["section"] == "composition"}
    assert (comp["n_malicious"]["primary_value"], comp["n_malicious"]["dedup_value"]) == (5, 3)
    assert comp["n_benign"]["delta"] == 0
    m = {(r["signal"], r["key"]): r for r in rows if r["section"] == "package_metric"}
    assert m[("guarddog", "recall")]["dedup_value"] == pytest.approx(2 / 3)       # m1, m4 of m1, m4, m5
    assert m[("guarddog", "recall")]["primary_value"] == pytest.approx(0.6)
    lab = {r["key"]: r for r in rows if r["section"] == "behavior_label_count"}
    assert lab["B4"]["primary_value"] == 3 and lab["B4"]["dedup_value"] == 2     # m3 removed
    rate = {(r["signal"], r["key"]): r for r in rows if r["section"] == "behavior_rate"}
    assert rate[("guarddog", "B4")]["dedup_denominator"] == 2


def test_normalized_hash_ignores_name_digits_comments_whitespace():
    a = {"setup.py": "# hi\nimport os\nos.system('curl http://x.invalid/1')   \n"}
    b = {"setup.py": "import os\n\n  os.system('curl http://x.invalid/22')\n# other comment\n"}
    c = {"setup.py": "import os\nos.system('wget http://x.invalid/1')\n"}
    assert normalized_code_hash(a, "pkg") == normalized_code_hash(b, "pkg")
    assert normalized_code_hash(a, "pkg") != normalized_code_hash(c, "pkg")
    assert normalized_code_hash({"s.py": "print('foo-1.0')"}, "foo") == normalized_code_hash({"s.py": "print('bar-2.0')"}, "bar")


def test_cluster_directory_reads_text_only(tmp_path):
    for name, code in (("p1", "import os\nos.system('x')"), ("p2", "# header\nimport os\n\nos.system('x')"), ("p3", "print(1)")):
        d = tmp_path / name
        d.mkdir()
        (d / "setup.py").write_text(code)
    (tmp_path / "p4").mkdir()                       # empty directory is a package with no python files
    m = cluster_directory(tmp_path)
    assert m["p1"] == m["p2"] != m["p3"]
