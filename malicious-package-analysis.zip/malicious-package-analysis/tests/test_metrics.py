import math

import pytest

from package_analysis.metrics import confusion, evaluate, package_metric_rows, rates


def test_confusion_counts_by_hand():
    truth = [1, 1, 1, 1, 0, 0, 0, 0, 0]
    pred = [1, 1, 0, None, 1, 0, 0, None, 0]
    c = confusion(truth, pred)
    assert c == {"TP": 2, "FP": 1, "TN": 3, "FN": 1, "unknown": 2}


def test_rates_match_hand_calculation():
    r = rates({"TP": 3, "FP": 1, "TN": 4, "FN": 2})
    assert r["precision"] == pytest.approx(0.75)
    assert r["recall"] == pytest.approx(0.6)
    assert r["f1"] == pytest.approx(2 * 0.75 * 0.6 / 1.35)
    assert r["fpr"] == pytest.approx(0.2)
    assert r["fnr"] == pytest.approx(0.4)
    assert r["accuracy"] == pytest.approx(0.7)


def test_zero_denominators_are_none_not_zero():
    r = rates({"TP": 0, "FP": 0, "TN": 5, "FN": 0})
    assert r["precision"] is None and r["recall"] is None and r["fnr"] is None
    assert r["f1"] is None
    assert r["fpr"] == 0.0
    r = rates({"TP": 0, "FP": 0, "TN": 0, "FN": 4})
    assert r["precision"] is None and r["fpr"] is None
    assert r["recall"] == 0.0


def test_f1_defined_when_no_hits_but_errors():
    # no true positives, one false positive, five misses: F1 = 0 (defined), precision = 0
    r = rates({"TP": 0, "FP": 1, "TN": 4, "FN": 5})
    assert r["f1"] == 0.0 and r["precision"] == 0.0


@pytest.mark.parametrize("sig,exp", [
    ("guarddog", dict(TP=3, FP=1, TN=4, FN=2, unknown=0, precision=0.75, recall=0.6, f1=6 / 9, fpr=0.2)),
    ("bandit", dict(TP=3, FP=2, TN=2, FN=2, unknown=1, precision=0.6, recall=0.6, f1=0.6, fpr=0.5)),
    ("osv_malicious", dict(TP=3, FP=0, TN=5, FN=2, unknown=0, precision=1.0, recall=0.6, f1=0.75, fpr=0.0)),
    ("osv_vulnerability", dict(TP=0, FP=1, TN=4, FN=5, unknown=0, precision=0.0, recall=0.0, f1=0.0, fpr=0.2)),
    ("guarddog_capability", dict(TP=5, FP=3, TN=2, FN=0, unknown=0, precision=0.625, recall=1.0, f1=10 / 13, fpr=0.6)),
])
def test_fixture_signals_match_hand_worked_values(ds, sig, exp):
    e = evaluate(ds, sig, sorted(ds.included))
    for k, v in exp.items():
        assert e[k] == pytest.approx(v), (sig, k)


def test_failed_run_is_unknown_not_negative(ds):
    assert ds.verdict("bandit", "b5") is None          # run failed
    assert ds.verdict("bandit", "b4") == 0             # observed negative
    assert ds.verdict("guarddog", "m3") == 0           # capability finding does not make a threat positive
    assert ds.verdict("guarddog_capability", "m3") == 1


def test_package_metric_rows_cover_all_signals(ds):
    pm, cm = package_metric_rows(ds, sorted(ds.included))
    assert {r["signal"] for r in pm} == set(ds.signals)
    assert all(r["analysis"] == "primary" for r in pm)
    g = next(r for r in cm if r["signal"] == "bandit")
    assert (g["n_malicious_evaluated"], g["n_benign_evaluated"], g["n_unknown_or_unrun"]) == (5, 4, 1)
