import csv
import json
import shutil
from pathlib import Path

import pytest

from package_analysis import io
from package_analysis.cli import main
from package_analysis.normalize import load_dataset, unmapped_rows
from package_analysis.pipeline import run
from package_analysis.schemas import ValidationError

from conftest import FIXTURE_CFG, ROOT

EXPECTED_FILES = {"package_metrics.csv", "confusion_matrices.csv", "bootstrap_intervals.csv",
                  "behavior_coverage.csv", "pairwise_complementarity.csv", "duplicate_sensitivity.csv",
                  "unmapped_findings.csv", "exclusions.csv", "experiment_manifest.json", "run_summary.md",
                  "paper_consistency.csv"}


def _edit(path: Path, fn):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    rows = fn(rows)
    with open(path, "w", newline="") as f:
        csv.writer(f, lineterminator="\n").writerows(rows)


# ---------- validation ----------
def test_missing_input_file_fails_clearly(copy_fixture):
    (copy_fixture.parent / "synthetic" / "findings.csv").unlink()
    with pytest.raises(ValidationError, match="not found"):
        load_dataset(copy_fixture)


def test_missing_required_column(copy_fixture):
    _edit(copy_fixture.parent / "synthetic" / "tool_runs.csv", lambda r: [[c for c in r[0] if c != "run_status"]] + [x[:4] + x[5:] for x in r[1:]])
    with pytest.raises(ValidationError, match="run_status"):
        load_dataset(copy_fixture)


def test_bad_label_duplicate_id_unresolved_reference_all_reported(copy_fixture):
    d = copy_fixture.parent / "synthetic"
    def corrupt(rows):
        rows[1][3] = "evil"                 # invalid label
        return rows + [rows[2][:]]          # duplicate package_id
    _edit(d / "package_manifest.csv", corrupt)
    _edit(d / "findings.csv", lambda r: r + [["ghost", "guarddog", "g9", "x", "threat", "", "", ""]])
    with pytest.raises(ValidationError) as e:
        load_dataset(copy_fixture)
    text = " | ".join(e.value.problems)
    assert "label 'evil'" in text and "duplicate package_id" in text and "unresolved package_id 'ghost'" in text


def test_synthetic_rows_rejected_unless_allowed(copy_fixture):
    cfg = copy_fixture.read_text().replace("allow_synthetic: true", "allow_synthetic: false")
    copy_fixture.write_text(cfg)
    with pytest.raises(ValidationError, match="synthetic"):
        load_dataset(copy_fixture)


def test_finding_for_failed_run_rejected(copy_fixture):
    _edit(copy_fixture.parent / "synthetic" / "findings.csv",
          lambda r: r + [["b5", "bandit", "b1", "B602", "code_analysis", "", "", ""]])
    with pytest.raises(ValidationError, match="status 'failed'"):
        load_dataset(copy_fixture)


def test_confirmed_positive_on_benign_rejected(copy_fixture):
    _edit(copy_fixture.parent / "synthetic" / "behavior_labels.csv",
          lambda r: r + [["b2", "B4", "confirmed_positive", "", "", ""]])
    with pytest.raises(ValidationError, match="benign"):
        load_dataset(copy_fixture)


def test_inconsistent_hash_labels_rejected(copy_fixture):
    def fn(rows):
        h = rows[1][5]
        rows[7][5] = h                      # a benign package given a malicious package's artifact hash
        return rows
    _edit(copy_fixture.parent / "synthetic" / "package_manifest.csv", fn)
    with pytest.raises(ValidationError, match="inconsistent labels"):
        load_dataset(copy_fixture)


def test_unknown_behavior_id_rejected(copy_fixture):
    _edit(copy_fixture.parent / "synthetic" / "behavior_labels.csv", lambda r: r + [["m1", "B13", "confirmed_positive", "", "", ""]])
    with pytest.raises(ValidationError, match="B13"):
        load_dataset(copy_fixture)


def test_exclusions_are_recorded_not_dropped_silently(ds):
    assert [e["package_id"] for e in ds.exclusions] == ["m6"]
    assert "m6" not in ds.included
    assert any("no sha256" in w for w in ds.warnings)


# ---------- unmapped findings ----------
def test_unmapped_findings_preserved_with_reasons(ds):
    rows = {(r["package_id"], r["rule_id"]): r["reason"] for r in unmapped_rows(ds)}
    assert rows[("m2", "threat-unknown-rule-x")] == "rule_not_in_mapping"
    assert rows[("m4", "capability-filesystem-delete")] == "no_behavior_in_taxonomy"
    # package-level feeds are never "unmapped behavior"
    assert not any(k[1].startswith(("MAL-", "GHSA-")) for k in rows)
    assert len(rows) == 2


def test_adapter_behaviors_used_when_rule_id_missing(ds):
    from package_analysis.schemas import BEHAVIORS
    assert all(set(f["behaviors"]) <= set(BEHAVIORS) for f in ds.findings)


# ---------- end to end ----------
def test_end_to_end_outputs_and_manifest(tmp_path):
    out = tmp_path / "out"
    res = run(FIXTURE_CFG, out)
    assert set(res["files"]) >= EXPECTED_FILES
    assert EXPECTED_FILES - {"paper_consistency.csv"} <= {p.name for p in out.iterdir()}
    mf = json.loads((out / "experiment_manifest.json").read_text())
    assert mf["mode"] == "test" and mf["data_class"] == "synthetic"
    assert mf["bootstrap"]["seed"] == 42 and mf["bootstrap"]["n_resamples"] == 200
    for key, info in mf["inputs"].items():
        assert info["sha256"] == io.sha256_file(info["path"])
    assert mf["sample_counts"] == {"manifest_rows": 11, "included": 10, "included_malicious": 5,
                                   "included_benign": 5, "excluded": 1}
    assert mf["tools_observed_in_inputs"]["bandit"]["run_status_counts"] == {"failed": 1, "ok": 9}
    assert mf["tools_observed_in_inputs"]["guarddog"]["execution_window"] == "not_recorded_in_inputs"
    assert mf["exclusions"] == {"no observable behavior (synthetic exclusion example)": 1}
    summary = (out / "run_summary.md").read_text()
    assert "TEST MODE" in summary and "Data class: synthetic" in summary


def test_pipeline_is_deterministic(tmp_path):
    run(FIXTURE_CFG, tmp_path / "a")
    run(FIXTURE_CFG, tmp_path / "b")
    for name in ("package_metrics.csv", "bootstrap_intervals.csv", "behavior_coverage.csv",
                 "pairwise_complementarity.csv", "duplicate_sensitivity.csv"):
        assert (tmp_path / "a" / name).read_text() == (tmp_path / "b" / name).read_text(), name


def test_undefined_values_written_as_NA(tmp_path):
    run(FIXTURE_CFG, tmp_path)
    rows = io.read_output(tmp_path / "behavior_coverage.csv")
    r = next(x for x in rows if x["signal"] == "bandit" and x["behavior_id"] == "B1")
    assert r["detection_rate"] == "NA" and r["status"] == "N/A"
    z = next(x for x in rows if x["signal"] == "guarddog" and x["behavior_id"] == "B8")
    assert z["detection_rate"] == "NA"


def test_dedup_stage_blocked_without_clusters(copy_fixture, tmp_path):
    _edit(copy_fixture.parent / "synthetic" / "package_manifest.csv",
          lambda r: [r[0]] + [x[:6] + [""] + x[7:] for x in r[1:]])
    res = run(copy_fixture, tmp_path / "o")
    assert res["stages"]["duplicate_sensitivity"].startswith("blocked")
    assert not (tmp_path / "o" / "duplicate_sensitivity.csv").exists()


def test_cli_exit_codes(tmp_path, capsys, copy_fixture):
    assert main(["validate", "--config", str(FIXTURE_CFG)]) == 0
    assert main(["run", "--config", str(FIXTURE_CFG), "--output-dir", str(tmp_path / "o"), "--test-mode"]) == 0
    assert main(["report", "--input", str(tmp_path / "o")]) == 0
    assert (tmp_path / "o" / "effective_config.yaml").is_file()
    (copy_fixture.parent / "synthetic" / "findings.csv").unlink()
    assert main(["validate", "--config", str(copy_fixture)]) == 2
    assert main(["report", "--input", str(tmp_path / "nothing")]) == 2
    assert "error" in capsys.readouterr().err


def test_consistency_internal_checks_run_on_fixture(tmp_path):
    run(FIXTURE_CFG, tmp_path)
    rows = io.read_output(tmp_path / "paper_consistency.csv")
    assert rows and all(r["check_id"].startswith("I") for r in rows)       # no data comparison for synthetic data
    assert not any(r["status"] == "inconsistent" for r in rows)


# ---------- optional integration on the real converted data ----------
REAL = ROOT / "config" / "experiment.yaml"


@pytest.mark.skipif(not (ROOT / "data" / "real" / "package_manifest.csv").exists(), reason="real data not present")
def test_real_data_reproduces_reported_confusion_counts(tmp_path):
    run(REAL, tmp_path)
    pm = {r["signal"]: r for r in io.read_output(tmp_path / "package_metrics.csv") if r["analysis"] == "primary"}
    assert (pm["guarddog"]["TP"], pm["guarddog"]["FP"], pm["guarddog"]["TN"], pm["guarddog"]["FN"]) == ("119", "32", "71", "3")
    assert (pm["osv_malicious"]["TP"], pm["osv_malicious"]["FP"]) == ("95", "0")
    cons = io.read_output(tmp_path / "paper_consistency.csv")
    assert not [r for r in cons if r["status"] == "inconsistent"]


def test_exclusion_sensitivity_counts_excluded_package_as_unknown_when_unrun(tmp_path):
    run(FIXTURE_CFG, tmp_path)
    rows = io.read_output(tmp_path / "package_metrics.csv")
    r = next(x for x in rows if x["analysis"] == "including_excluded" and x["signal"] == "guarddog")
    # m6 has no tool runs in the fixture: it is unknown (not a false negative) in every signal
    assert r["n_unknown_or_unrun"] == "1" and r["FN"] == "2"
    assert "including_excluded" in (tmp_path / "run_summary.md").read_text()
