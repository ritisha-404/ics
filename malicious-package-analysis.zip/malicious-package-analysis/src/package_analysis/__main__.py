from package_analysis.cli import main

raise SystemExit(main())
