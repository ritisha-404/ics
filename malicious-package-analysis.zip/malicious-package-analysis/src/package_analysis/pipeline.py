"""Run all stages in order and write the output artifacts."""
from __future__ import annotations

from pathlib import Path

from . import io
from .behavior_coverage import COV_COLUMNS, coverage_rows
from .bootstrap import BOOT_COLUMNS, bootstrap_rows
from .complementarity import COMP_COLUMNS, pairwise_rows
from .consistency import CC_COLUMNS, data_checks, internal_checks
from .deduplication import DUP_COLUMNS, duplicate_rows, has_clusters, select_representatives
from .metrics import CM_COLUMNS, PM_COLUMNS, evaluate, package_metric_rows
from .normalize import Dataset, load_dataset, unmapped_rows
from .provenance import build_manifest
from .report import write_summary

TEST_RESAMPLES = 200


def run(config_path: str | Path, out_dir: str | Path, test_mode: bool = False) -> dict:
    ds = load_dataset(config_path)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    mode = "test" if (test_mode or ds.config.get("mode") == "test") else "full"
    n_boot = TEST_RESAMPLES if mode == "test" else int(ds.config.get("bootstrap", {}).get("n_resamples", 2000))
    seed = int(ds.config.get("bootstrap", {}).get("seed", 42))
    stages: dict[str, str] = {"validate": "completed"}
    written: list[str] = []

    def emit(name: str, rows: list[dict], cols: list[str]) -> None:
        io.write_csv(out / name, rows, cols)
        written.append(name)

    primary = sorted(ds.included)
    pm, cm = package_metric_rows(ds, primary, "primary")
    stages["package_metrics"] = "completed"
    point = {r["signal"]: evaluate(ds, r["signal"], primary) for r in pm}
    boot = bootstrap_rows(ds, primary, point, "primary", "package", n_boot, seed)
    stages["bootstrap_package"] = "completed"
    cov = coverage_rows(ds, primary, "primary")
    stages["behavior_coverage"] = "completed"
    pairs = pairwise_rows(ds, primary, "primary")
    stages["pairwise_complementarity"] = "completed" if any(p["status"] == "ok" for p in pairs) else \
        "blocked: fewer than two eligible signals with data"

    dup_rows: list[dict] = []
    dedup_info: dict = {"performed": False}
    cluster_boot = ds.config.get("bootstrap", {}).get("cluster_sensitivity", True)
    if has_clusters(ds):
        keep, removed = select_representatives(ds)
        pm2, cm2 = package_metric_rows(ds, keep, "deduplicated")
        pm += pm2; cm += cm2
        point2 = {r["signal"]: evaluate(ds, r["signal"], keep) for r in pm2}
        boot += bootstrap_rows(ds, keep, point2, "deduplicated", "package", n_boot, seed)
        cov += coverage_rows(ds, keep, "deduplicated")
        pairs += pairwise_rows(ds, keep, "deduplicated")
        dup_rows = duplicate_rows(ds, primary, keep, removed)
        if cluster_boot:
            boot += bootstrap_rows(ds, primary, point, "primary", "cluster", n_boot, seed)
        emit("duplicate_sensitivity.csv", dup_rows, DUP_COLUMNS)
        emit("duplicate_removed_ids.csv", removed, ["package_id", "cluster", "representative"])
        stages["duplicate_sensitivity"] = "completed"
        dedup_info = {"performed": True, "n_retained": len(keep), "n_removed": len(removed),
                      "cluster_bootstrap": bool(cluster_boot),
                      "cluster_benign": bool(ds.config.get("deduplication", {}).get("cluster_benign", False))}
    else:
        stages["duplicate_sensitivity"] = "blocked: no duplicate_cluster assignments for malicious packages in the manifest"

    # Extension: how much do the manifest exclusions matter? Re-score with excluded packages counted
    # (they keep their ground-truth package label; only their behavior annotation was missing).
    if ds.exclusions and ds.config.get("exclusion_sensitivity", True):
        import copy
        ds_all = copy.copy(ds)
        ds_all.included = {r["package_id"]: r for r in ds.manifest}
        allp = sorted(ds_all.included)
        pm3, cm3 = package_metric_rows(ds_all, allp, "including_excluded")
        if pm3:
            pm += pm3; cm += cm3
            point3 = {r["signal"]: evaluate(ds_all, r["signal"], allp) for r in pm3}
            boot += bootstrap_rows(ds_all, allp, point3, "including_excluded", "package", n_boot, seed)
            stages["exclusion_sensitivity"] = "completed"
    emit("package_metrics.csv", pm, PM_COLUMNS)
    emit("confusion_matrices.csv", cm, CM_COLUMNS)
    emit("bootstrap_intervals.csv", boot, BOOT_COLUMNS)
    emit("behavior_coverage.csv", cov, COV_COLUMNS)
    if pairs:
        emit("pairwise_complementarity.csv", pairs, COMP_COLUMNS)
    emit("unmapped_findings.csv", unmapped_rows(ds),
         ["package_id", "tool", "finding_id", "rule_id", "finding_category", "reason", "raw_evidence"])
    emit("exclusions.csv", ds.exclusions, ["package_id", "label", "reason", "stage"])

    # consistency checks against the paper's reported values
    ref_name = ds.config.get("paper_reference")
    if ref_name:
        ref = io.load_yaml((Path(ds.config["_base"]) / ref_name).resolve())
        rows = internal_checks(ref)
        manifest_data_class_real = all(r["data_origin"] == "real" for r in ds.manifest)
        if manifest_data_class_real and mode == "full":
            rows += data_checks(ref, [{**r} for r in pm], boot, cov, pairs, dup_rows)
            stages["paper_consistency"] = "completed (internal arithmetic + comparison with recomputed values)"
        else:
            stages["paper_consistency"] = "partial: internal arithmetic only (data comparison needs real data in full mode)"
        emit("paper_consistency.csv", rows, CC_COLUMNS)
    else:
        stages["paper_consistency"] = "skipped: no paper_reference configured"

    manifest = build_manifest(ds, written, stages,
                              {"method": "percentile", "n_resamples": n_boot, "seed": seed,
                               "resampling_unit": "package (cluster variant: duplicate cluster)",
                               "confidence": 0.95}, dedup_info, mode)
    import json
    (out / "experiment_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    written.append("experiment_manifest.json")
    write_summary(out)
    written.append("run_summary.md")
    return {"output_dir": str(out), "mode": mode, "files": sorted(written), "stages": stages}
