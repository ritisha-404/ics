"""Load, validate and normalize inputs.

Normalization rules (versioned by ``mapping_version`` in behavior_mapping.yaml):

* A *signal* is a named package-level prediction defined in experiment.yaml: a tool plus
  the finding categories that count as a positive. One tool can back several signals
  (GuardDog backs both ``guarddog`` = threat rules and ``guarddog_capability`` = any rule).
* Signal verdict for a package:
    flagged      tool run ok and at least one finding in the signal's categories
    not_flagged  tool run ok and no such finding (an observed negative)
    unknown      no run record, or run_status failed/unavailable (never a negative)
* A finding supports a behavior only through behavior_mapping.yaml (or an explicit
  ``adapter_behaviors`` value when the adapter could not retain the rule id). Findings
  that map to nothing are kept and written to unmapped_findings.csv.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from . import io
from .schemas import (ANNOTATION_STATUSES, BEHAVIORS, DATA_ORIGINS, FINDING_CATEGORIES,
                      FINDINGS_OPTIONAL, FINDINGS_REQUIRED, LABELS, LABELS_OPTIONAL,
                      LABELS_REQUIRED, MANIFEST_OPTIONAL, MANIFEST_REQUIRED, RUN_STATUSES,
                      RUNS_OPTIONAL, RUNS_REQUIRED, ValidationError)

HEX64 = set("0123456789abcdef")


@dataclass
class Dataset:
    config: dict
    mapping: dict
    manifest: list[dict]
    included: dict[str, dict]              # package_id -> manifest row (analysis universe)
    exclusions: list[dict]
    runs: dict[tuple[str, str], dict]      # (package_id, tool) -> run row
    findings: list[dict]                   # normalized findings (with behaviors, mapping_status)
    labels: list[dict]
    input_paths: dict[str, Path]
    warnings: list[str] = field(default_factory=list)

    # ---- derived helpers -------------------------------------------------
    @property
    def signals(self) -> dict[str, dict]:
        return self.config["signals"]

    def truth(self, pid: str) -> int:
        return 1 if self.included[pid]["label"] == "malicious" else 0

    def verdict(self, signal: str, pid: str) -> int | None:
        """1 flagged, 0 not flagged, None unknown."""
        cfg = self.signals[signal]
        run = self.runs.get((pid, cfg["tool"]))
        if run is None or run["run_status"] != "ok":
            return None
        cats = set(cfg["finding_categories"])
        return 1 if any(f["package_id"] == pid and f["tool"] == cfg["tool"]
                        and f["finding_category"] in cats for f in self._by_pid.get(pid, [])) else 0

    @property
    def _by_pid(self) -> dict[str, list[dict]]:
        if not hasattr(self, "_idx"):
            idx: dict[str, list[dict]] = defaultdict(list)
            for f in self.findings:
                idx[f["package_id"]].append(f)
            object.__setattr__(self, "_idx", idx)
        return self._idx  # type: ignore[attr-defined]

    def signal_vector(self, signal: str, pids: list[str]) -> list[int | None]:
        return [self.verdict(signal, p) for p in pids]

    def signal_has_data(self, signal: str) -> bool:
        """True if at least one included package has a usable (ok) run for the signal's tool."""
        tool = self.signals[signal]["tool"]
        return any((p, tool) in self.runs and self.runs[(p, tool)]["run_status"] == "ok"
                   for p in self.included)

    def behavior_hits(self, signal: str, pid: str) -> set[str] | None:
        """Behaviors supported by the signal's behavior-evidence findings; None if run not ok."""
        cfg = self.signals[signal]
        run = self.runs.get((pid, cfg["tool"]))
        if run is None or run["run_status"] != "ok":
            return None
        cats = set(cfg.get("behavior_categories") or [])
        out: set[str] = set()
        for f in self._by_pid.get(pid, []):
            if f["tool"] == cfg["tool"] and f["finding_category"] in cats:
                out.update(f["behaviors"])
        return out

    def positives(self, pids: list[str] | None = None) -> dict[str, set[str]]:
        """pid -> behaviors with annotation_status == confirmed_positive (included packages)."""
        keep = set(pids) if pids is not None else set(self.included)
        out: dict[str, set[str]] = defaultdict(set)
        for r in self.labels:
            if r["package_id"] in keep and r["annotation_status"] == "confirmed_positive":
                out[r["package_id"]].add(r["behavior_id"])
        return out

    def unknown_labels(self, pids: list[str] | None = None) -> Counter:
        keep = set(pids) if pids is not None else set(self.included)
        return Counter(r["behavior_id"] for r in self.labels
                       if r["package_id"] in keep and r["annotation_status"] == "unknown")


def load_config(path: str | Path) -> tuple[dict, dict]:
    path = Path(path)
    cfg = io.load_yaml(path)
    base = path.parent
    cfg["_config_path"] = str(path)
    cfg["_base"] = str(base)
    inputs = cfg.get("inputs") or {}
    for key in ("package_manifest", "tool_runs", "findings", "behavior_labels", "behavior_mapping"):
        if key not in inputs:
            raise ValidationError([f"{path.name}: inputs.{key} is required"])
    for key in ("signals",):
        if not cfg.get(key):
            raise ValidationError([f"{path.name}: '{key}' is required"])
    mapping = io.load_yaml((base / inputs["behavior_mapping"]).resolve())
    return cfg, mapping


def _p(cfg: dict, key: str) -> Path:
    return (Path(cfg["_base"]) / cfg["inputs"][key]).resolve()


def load_dataset(config_path: str | Path) -> Dataset:
    cfg, mapping = load_config(config_path)
    problems: list[str] = []
    warnings: list[str] = []
    paths = {k: _p(cfg, k) for k in ("package_manifest", "tool_runs", "findings", "behavior_labels")}
    paths["behavior_mapping"] = (Path(cfg["_base"]) / cfg["inputs"]["behavior_mapping"]).resolve()
    paths["config"] = Path(cfg["_config_path"]).resolve()

    # signals sanity
    for name, s in cfg["signals"].items():
        for k in ("tool", "finding_categories"):
            if k not in s:
                problems.append(f"signal '{name}': '{k}' missing")
        for c in list(s.get("finding_categories") or []) + list(s.get("behavior_categories") or []):
            if c not in FINDING_CATEGORIES:
                problems.append(f"signal '{name}': unknown finding category '{c}'")

    manifest = io.read_table(paths["package_manifest"], MANIFEST_REQUIRED, MANIFEST_OPTIONAL)
    runs_raw = io.read_table(paths["tool_runs"], RUNS_REQUIRED, RUNS_OPTIONAL)
    findings_raw = io.read_table(paths["findings"], FINDINGS_REQUIRED, FINDINGS_OPTIONAL)
    labels = io.read_table(paths["behavior_labels"], LABELS_REQUIRED, LABELS_OPTIONAL)

    # ---- manifest ----
    seen: dict[str, int] = {}
    ident: dict[tuple, dict] = {}
    for r in manifest:
        pid = r["package_id"]
        if not pid:
            problems.append(f"manifest line {r['_line']}: empty package_id")
            continue
        if pid in seen:
            problems.append(f"manifest line {r['_line']}: duplicate package_id '{pid}' (first at line {seen[pid]})")
        seen[pid] = r["_line"]
        if r["label"] not in LABELS:
            problems.append(f"manifest line {r['_line']}: label '{r['label']}' not in {LABELS}")
        if r["data_origin"] not in DATA_ORIGINS:
            problems.append(f"manifest line {r['_line']}: data_origin '{r['data_origin']}' not in {DATA_ORIGINS}")
        if r["sha256"] and (len(r["sha256"]) != 64 or set(r["sha256"].lower()) - HEX64):
            problems.append(f"manifest line {r['_line']}: sha256 for '{pid}' is not 64 hex characters")
        key = (r["package_name"], r["version"], r["sha256"].lower())
        if r["package_name"]:
            prev = ident.get(key)
            if prev and prev["package_id"] != pid:
                problems.append(f"manifest: '{pid}' and '{prev['package_id']}' have the same name/version/sha256")
            ident[key] = r
    # same artifact hash, different label
    by_hash: dict[str, set[str]] = defaultdict(set)
    for r in manifest:
        if r["sha256"]:
            by_hash[r["sha256"].lower()].add(r["label"])
    for h, ls in by_hash.items():
        if len(ls) > 1:
            problems.append(f"manifest: artifact sha256 {h[:12]}... carries inconsistent labels {sorted(ls)}")
    n_nohash = sum(1 for r in manifest if not r["sha256"])
    if n_nohash:
        warnings.append(f"{n_nohash} manifest row(s) have no sha256; artifact identity rests on package_id only")
    n_nover = sum(1 for r in manifest if not r["version"])
    if n_nover:
        warnings.append(f"{n_nover} manifest row(s) have no version")
    if not cfg.get("allow_synthetic", False):
        syn = [r["package_id"] for r in manifest if r["data_origin"] == "synthetic"]
        if syn:
            problems.append(f"{len(syn)} synthetic manifest row(s) (e.g. '{syn[0]}') but allow_synthetic is false; "
                            "synthetic fixtures are not allowed in paper-reproduction runs")

    ids = set(seen)
    # ---- runs ----
    runs: dict[tuple[str, str], dict] = {}
    for r in runs_raw:
        if r["package_id"] not in ids:
            problems.append(f"tool_runs line {r['_line']}: unresolved package_id '{r['package_id']}'")
            continue
        if r["run_status"] not in RUN_STATUSES:
            problems.append(f"tool_runs line {r['_line']}: run_status '{r['run_status']}' not in {RUN_STATUSES}")
        k = (r["package_id"], r["tool"])
        if k in runs:
            problems.append(f"tool_runs line {r['_line']}: duplicate run for {k}")
        runs[k] = r
    # ---- findings ----
    seen_f: set[tuple] = set()
    findings: list[dict] = []
    for r in findings_raw:
        if r["package_id"] not in ids:
            problems.append(f"findings line {r['_line']}: unresolved package_id '{r['package_id']}'")
            continue
        if r["finding_category"] not in FINDING_CATEGORIES:
            problems.append(f"findings line {r['_line']}: finding_category '{r['finding_category']}' invalid")
        k = (r["package_id"], r["tool"], r["finding_id"])
        if k in seen_f:
            problems.append(f"findings line {r['_line']}: duplicate finding {k}")
        seen_f.add(k)
        run = runs.get((r["package_id"], r["tool"]))
        if run is None:
            problems.append(f"findings line {r['_line']}: finding for ({r['package_id']}, {r['tool']}) has no tool_runs record")
        elif run["run_status"] != "ok":
            problems.append(f"findings line {r['_line']}: finding recorded for a run with status '{run['run_status']}'")
        findings.append(dict(r))
    # ---- labels ----
    seen_l: set[tuple] = set()
    for r in labels:
        if r["package_id"] not in ids:
            problems.append(f"behavior_labels line {r['_line']}: unresolved package_id '{r['package_id']}'")
        if r["behavior_id"] not in BEHAVIORS:
            problems.append(f"behavior_labels line {r['_line']}: behavior_id '{r['behavior_id']}' not in taxonomy")
        if r["annotation_status"] not in ANNOTATION_STATUSES:
            problems.append(f"behavior_labels line {r['_line']}: annotation_status '{r['annotation_status']}' invalid")
        k = (r["package_id"], r["behavior_id"])
        if k in seen_l:
            problems.append(f"behavior_labels line {r['_line']}: duplicate annotation for {k}")
        seen_l.add(k)
    label_of = {r["package_id"]: r["label"] for r in manifest}
    for r in labels:
        if r["annotation_status"] == "confirmed_positive" and label_of.get(r["package_id"]) == "benign":
            problems.append(f"behavior_labels line {r['_line']}: confirmed_positive behavior on benign package '{r['package_id']}'")
    # mapping sanity
    for tool, tcfg in (mapping.get("tools") or {}).items():
        for rule, spec in (tcfg.get("rules") or {}).items():
            for b in spec.get("behaviors", []):
                if b not in BEHAVIORS:
                    problems.append(f"behavior_mapping: {tool}/{rule} maps to unknown behavior '{b}'")
    if problems:
        raise ValidationError(problems)

    # ---- exclusions ----
    included: dict[str, dict] = {}
    exclusions: list[dict] = []
    for r in manifest:
        if r["exclusion_reason"]:
            exclusions.append({"package_id": r["package_id"], "label": r["label"],
                               "reason": r["exclusion_reason"], "stage": "manifest"})
        else:
            included[r["package_id"]] = r
    if not included:
        raise ValidationError(["no packages remain after exclusions"])
    pos = {r["package_id"] for r in labels if r["annotation_status"] == "confirmed_positive"}
    n_nolabel = sum(1 for p, r in included.items() if r["label"] == "malicious" and p not in pos)
    if n_nolabel:
        warnings.append(f"{n_nolabel} included malicious package(s) have no confirmed_positive behavior "
                        "annotation; they count in package metrics but contribute no behavior instances")
    for sig in cfg["signals"]:
        tool = cfg["signals"][sig]["tool"]
        if not any(t == tool for (_, t) in runs):
            warnings.append(f"signal '{sig}': no tool_runs for tool '{tool}'; signal is unavailable")

    # ---- map findings to behaviors ----
    tools_map = mapping.get("tools") or {}
    for f in findings:
        tspec = tools_map.get(f["tool"]) or {}
        if tspec and not tspec.get("behavior_reporting", True) and not f["adapter_behaviors"]:
            f["behaviors"] = []; f["mapping_status"] = "package_level_only"
            f["mapping_rationale"] = "tool provides package-level signals only; never mapped to behaviors"
            continue
        tmap = tspec.get("rules") or {}
        spec = tmap.get(f["rule_id"])
        if spec is not None and spec.get("behaviors"):
            f["behaviors"] = list(spec["behaviors"]); f["mapping_status"] = "mapped"
            f["mapping_rationale"] = spec.get("rationale", "")
        elif f["adapter_behaviors"]:
            f["behaviors"] = io.split_list(f["adapter_behaviors"])
            bad = [b for b in f["behaviors"] if b not in BEHAVIORS]
            if bad:
                raise ValidationError([f"finding {f['finding_id']}: adapter_behaviors has unknown id(s) {bad}"])
            f["mapping_status"] = "mapped_by_adapter"
            f["mapping_rationale"] = "behavior supplied by the adapter; rule id not retained in source data"
        elif spec is not None:
            f["behaviors"] = []; f["mapping_status"] = "no_behavior_in_taxonomy"
            f["mapping_rationale"] = spec.get("rationale", "rule intentionally maps to no behavior")
        else:
            f["behaviors"] = []; f["mapping_status"] = "rule_not_in_mapping"
            f["mapping_rationale"] = ""
    return Dataset(cfg, mapping, manifest, included, exclusions, runs, findings, labels, paths, warnings)


def unmapped_rows(ds: Dataset) -> list[dict]:
    rows = []
    for f in ds.findings:
        if f["mapping_status"] in ("rule_not_in_mapping", "no_behavior_in_taxonomy"):
            if f["package_id"] in ds.included:
                rows.append({"package_id": f["package_id"], "tool": f["tool"], "finding_id": f["finding_id"],
                             "rule_id": f["rule_id"], "finding_category": f["finding_category"],
                             "reason": f["mapping_status"], "raw_evidence": f["raw_evidence"]})
    rows.sort(key=lambda r: (r["tool"], r["rule_id"], r["package_id"], r["finding_id"]))
    return rows
