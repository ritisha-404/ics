"""Constants and column definitions shared by all modules.

Behavior identifiers B1..B12 follow the paper's taxonomy and must not be renamed.
"""
from __future__ import annotations

BEHAVIORS = {
    "B1": "System/environment discovery",
    "B2": "Credential/secret access",
    "B3": "Sensitive-file collection",
    "B4": "Command/process execution",
    "B5": "Payload download",
    "B6": "Payload execution",
    "B7": "Encoding/obfuscation",
    "B8": "Network communication",
    "B9": "Data exfiltration",
    "B10": "Persistence",
    "B11": "Dependency manipulation",
    "B12": "Evasion/environment gating",
}
BEHAVIOR_IDS = tuple(BEHAVIORS)

LABELS = ("malicious", "benign")
DATA_ORIGINS = ("real", "synthetic")
RUN_STATUSES = ("ok", "failed", "unavailable")
FINDING_CATEGORIES = ("threat", "capability", "feed_match", "vulnerability", "code_analysis")

# Annotation statuses. An absent (package, behavior) row means "unannotated" and is
# never interpreted as a negative.
#   confirmed_positive : annotator established that the behavior is present
#   confirmed_negative : annotator established that the behavior is absent
#   unknown            : annotator looked and could not decide
#   capability_only    : capability observed, no malicious intent established
ANNOTATION_STATUSES = ("confirmed_positive", "confirmed_negative", "unknown", "capability_only")

MANIFEST_REQUIRED = ["package_id", "label", "source", "data_origin"]
MANIFEST_OPTIONAL = ["package_name", "version", "sha256", "duplicate_cluster", "exclusion_reason", "notes"]
RUNS_REQUIRED = ["package_id", "tool", "run_status"]
RUNS_OPTIONAL = ["tool_version", "executed_at", "rule_set_version"]
FINDINGS_REQUIRED = ["package_id", "tool", "finding_id", "rule_id", "finding_category"]
FINDINGS_OPTIONAL = ["raw_evidence", "evidence_source", "adapter_behaviors"]
LABELS_REQUIRED = ["package_id", "behavior_id", "annotation_status"]
LABELS_OPTIONAL = ["evidence_ref", "annotator", "notes"]


class ValidationError(Exception):
    """Raised when inputs are missing or malformed. Carries every problem found."""

    def __init__(self, problems: list[str]):
        self.problems = list(problems)
        super().__init__("; ".join(self.problems[:5]) + (f" (+{len(self.problems) - 5} more)" if len(self.problems) > 5 else ""))
