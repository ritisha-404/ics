"""Render run_summary.md from the CSV/JSON outputs in a directory (used by `run` and `report`)."""
from __future__ import annotations

import json
from pathlib import Path

from . import io

LIMITS = [
    "Results describe this curated benchmark only. They are not ecosystem-wide performance estimates.",
    "The malicious set was largely discovered with GuardDog, which can inflate GuardDog's apparent recall.",
    "The benign set is hand-selected, so precision and FPR are conditional on it.",
    "Bootstrap intervals capture resampling variability only, not selection bias, label error or incomplete ground truth.",
    "Behavior labels come from the supplied annotations; absent annotations are not negatives, and a missed static finding does not show a behavior is absent.",
    "A capability finding is not evidence of malicious intent. This run does not test whether chain-aware detection reduces false positives.",
]


def _f(x: str) -> str:
    try:
        return f"{float(x):.3f}"
    except (TypeError, ValueError):
        return x if x else ""


def _table(headers: list[str], rows: list[list[str]]) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    out += ["| " + " | ".join(r) + " |" for r in rows]
    return "\n".join(out)


def write_summary(out_dir: str | Path) -> Path:
    d = Path(out_dir)
    mf = json.loads((d / "experiment_manifest.json").read_text(encoding="utf-8"))
    L: list[str] = ["# Run summary", ""]
    if mf["mode"] == "test":
        L += ["> **TEST MODE.** Fewer bootstrap resamples and/or fixture data. Do not quote these numbers.", ""]
    if mf["data_class"] != "real":
        L += [f"> **Data class: {mf['data_class']}.** Results from synthetic or mixed data are not empirical findings.", ""]
    sc = mf["sample_counts"]
    L += [f"Experiment: `{mf['experiment_id']}`  |  mode: {mf['mode']}  |  data: {mf['data_class']}  |  run (UTC): {mf['run_timestamp_utc']}",
          "", f"Included packages: {sc['included']} ({sc['included_malicious']} malicious, {sc['included_benign']} benign); "
              f"excluded: {sc['excluded']}. Bootstrap: {mf['bootstrap']['n_resamples']} resamples, seed {mf['bootstrap']['seed']}, "
              f"unit = package.", "", "## Stage status", ""]
    L += [f"- {k}: {v}" for k, v in mf["stages"].items()]
    pm = [r for r in io.read_output(d / "package_metrics.csv")]
    bi = {(r["analysis"], r["method"], r["signal"], r["metric"]): r for r in io.read_output(d / "bootstrap_intervals.csv")}
    def ci(a, s, m):
        r = bi.get((a, "package", s, m))
        return "" if not r or r["ci_low"] == "NA" else f" ({_f(r['ci_low'])} to {_f(r['ci_high'])})"
    for analysis in ("primary", "deduplicated", "including_excluded"):
        rows = [r for r in pm if r["analysis"] == analysis]
        if not rows:
            continue
        note = {"including_excluded": "Sensitivity: packages excluded for lack of a behavior annotation are scored with their package label. ",
                "deduplicated": "Sensitivity: one representative per duplicate cluster. "}.get(analysis, "")
        L += ["", f"## Package-level metrics ({analysis})", "", note, "",
              _table(["Signal", "Type", "Precision", "Recall (95% CI)", "F1", "FPR (95% CI)", "TP", "FP", "TN", "FN", "Unknown"],
                     [[r["signal"] + (" *(negative control)*" if r["negative_control"] == "true" else ""), r["signal_type"],
                       _f(r["precision"]), _f(r["recall"]) + ci(analysis, r["signal"], "recall"), _f(r["f1"]),
                       _f(r["fpr"]) + ci(analysis, r["signal"], "fpr"), r["TP"], r["FP"], r["TN"], r["FN"],
                       r["n_unknown_or_unrun"]] for r in rows])]
    cov = [r for r in io.read_output(d / "behavior_coverage.csv") if r["analysis"] == "primary" and r["signal"] != "union"]
    un = {r["behavior_id"]: r for r in io.read_output(d / "behavior_coverage.csv")
          if r["analysis"] == "primary" and r["signal"] == "union"}
    sigs = sorted({r["signal"] for r in cov})
    by = {(r["behavior_id"], r["signal"]): r for r in cov}
    def cell(r):
        if r is None or r["applicability"] != "applicable":
            return "N/A"
        return f"{r['n_detected']}/{r['n_evaluated']} ({_f(r['detection_rate'])})" if r["n_evaluated"] not in ("", "NA") and r["detection_rate"] != "NA" else "no instances"
    rows = []
    for b in dict.fromkeys(r["behavior_id"] for r in cov):
        u = un.get(b)
        rows.append([b, by[(b, sigs[0])]["behavior_name"], by[(b, sigs[0])]["n_confirmed_positive"]] +
                    [cell(by.get((b, s))) for s in sigs] + [cell(u), (u or {}).get("status", "")])
    L += ["", "## Behavior-level coverage (primary)", "",
          "Rates are detected/evaluated labeled instances. N/A = tool not applicable (not zero).", "",
          _table(["ID", "Behavior", "n labeled"] + sigs + ["union", "status"], rows)]
    pw = [r for r in io.read_output(d / "pairwise_complementarity.csv")] if (d / "pairwise_complementarity.csv").exists() else []
    pw = [r for r in pw if r["analysis"] == "primary"]
    if pw:
        L += ["", "## Pairwise complementarity (primary)", "",
              "Read recall gain together with the false-positive increase. A higher union recall is not automatically a better detector.", "",
              _table(["A", "B", "Recall A", "Recall B", "Union recall", "Gain", "FPR A", "FPR B", "Union FPR", "Jaccard", "Status"],
                     [[r["signal_a"], r["signal_b"], _f(r["recall_a"]), _f(r["recall_b"]), _f(r["recall_union"]),
                       _f(r["recall_gain"]), _f(r["fpr_a"]), _f(r["fpr_b"]), _f(r["fpr_union"]),
                       _f(r["jaccard_positive_sets"]), r["status"]] for r in pw])]
    if (d / "duplicate_sensitivity.csv").exists():
        comp = [r for r in io.read_output(d / "duplicate_sensitivity.csv") if r["section"] == "composition"]
        L += ["", "## Duplicate sensitivity", "",
              _table(["Quantity", "Primary", "Deduplicated", "Delta"], [[r["key"], r["primary_value"], r["dedup_value"], r["delta"]] for r in comp]),
              "", "Deduplication changes sample composition. The retained set is not an independent or representative sample."]
    um = io.read_output(d / "unmapped_findings.csv")
    from collections import Counter
    by_reason = Counter(r["reason"] for r in um)
    L += ["", "## Mapping and exclusions", "",
          f"- Behavior-reporting findings with no behavior mapping (kept in unmapped_findings.csv): {len(um)}"
          + (" (" + ", ".join(f"{k}: {v}" for k, v in sorted(by_reason.items())) + ")" if um else ""),
          f"- Excluded packages (exclusions.csv): {sc['excluded']}"]
    if (d / "paper_consistency.csv").exists():
        cc = io.read_output(d / "paper_consistency.csv")
        cnt = {s: sum(1 for r in cc if r["status"] == s) for s in ("consistent", "minor_difference", "inconsistent", "not_available")}
        L += [f"- Paper consistency checks: {cnt['consistent']} consistent, {cnt['minor_difference']} minor difference (CI endpoints), "
              f"{cnt['inconsistent']} inconsistent, {cnt['not_available']} not available (paper_consistency.csv)"]
    if mf["warnings"]:
        L += ["", "## Warnings", ""] + [f"- {w}" for w in mf["warnings"]]
    L += ["", "## Limitations that apply to every number above", ""] + [f"- {x}" for x in LIMITS]
    p = d / "run_summary.md"
    p.write_text("\n".join(L) + "\n", encoding="utf-8")
    return p
