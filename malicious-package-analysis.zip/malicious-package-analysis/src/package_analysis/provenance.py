"""Experiment manifest: what was run, on what, with which versions. Records only observed facts."""
from __future__ import annotations

import hashlib
import json
import platform
import sys
from collections import Counter
from datetime import datetime, timezone
from importlib import metadata

from . import __version__, io
from .normalize import Dataset

NOT_RECORDED = "not_recorded_in_inputs"


def config_hash(cfg: dict) -> str:
    clean = {k: v for k, v in cfg.items() if not k.startswith("_")}
    return hashlib.sha256(json.dumps(clean, sort_keys=True, default=str).encode()).hexdigest()


def _versions(*names: str) -> dict:
    out = {}
    for n in names:
        try:
            out[n] = metadata.version(n)
        except metadata.PackageNotFoundError:
            out[n] = "not_installed"
    return out


def build_manifest(ds: Dataset, outputs: list[str], stages: dict[str, str], bootstrap: dict,
                   dedup_info: dict, mode: str) -> dict:
    origins = Counter(r["data_origin"] for r in ds.manifest)
    if set(origins) == {"real"}:
        data_class = "real"
    elif set(origins) == {"synthetic"}:
        data_class = "synthetic"
    else:
        data_class = "mixed"
    tool_obs: dict[str, dict] = {}
    for (_, tool), run in ds.runs.items():
        t = tool_obs.setdefault(tool, {"tool_versions": set(), "rule_set_versions": set(), "timestamps": [],
                                       "runs": Counter()})
        t["runs"][run["run_status"]] += 1
        if run["tool_version"]:
            t["tool_versions"].add(run["tool_version"])
        if run["rule_set_version"]:
            t["rule_set_versions"].add(run["rule_set_version"])
        if run["executed_at"]:
            t["timestamps"].append(run["executed_at"])
    tools = {}
    for tool, t in sorted(tool_obs.items()):
        tools[tool] = {
            "tool_versions": sorted(t["tool_versions"]) or NOT_RECORDED,
            "rule_set_versions": sorted(t["rule_set_versions"]) or NOT_RECORDED,
            "execution_window": ([min(t["timestamps"]), max(t["timestamps"])] if t["timestamps"] else NOT_RECORDED),
            "run_status_counts": dict(sorted(t["runs"].items())),
        }
    labels = Counter(r["label"] for r in ds.included.values())
    excl = Counter(e["reason"] for e in ds.exclusions)
    return {
        "experiment_id": ds.config.get("experiment_id", "unnamed"),
        "mode": mode,
        "data_class": data_class,
        "data_origin_counts": dict(sorted(origins.items())),
        "run_timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "config_hash_sha256": config_hash(ds.config),
        "mapping_version": ds.mapping.get("mapping_version", NOT_RECORDED),
        "normalization_version": ds.config.get("normalization_version", NOT_RECORDED),
        "inputs": {k: {"path": str(p), "sha256": io.sha256_file(p)} for k, p in sorted(ds.input_paths.items())},
        "sample_counts": {"manifest_rows": len(ds.manifest), "included": len(ds.included),
                          "included_malicious": labels.get("malicious", 0),
                          "included_benign": labels.get("benign", 0), "excluded": len(ds.exclusions)},
        "exclusions": dict(sorted(excl.items())),
        "tools_observed_in_inputs": tools,
        "bootstrap": bootstrap,
        "deduplication": dedup_info,
        "stages": stages,
        "outputs": sorted(outputs),
        "software": {"package_analysis": __version__, "python": sys.version.split()[0],
                     "platform": platform.platform(), **_versions("numpy", "PyYAML")},
        "warnings": ds.warnings,
    }
