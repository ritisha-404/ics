"""Pairwise union analysis of package-level signals (paper eq. 7 and 8).

For a pair (A, B) the universe is the set of included packages for which BOTH signals have
a usable verdict, so individual and union metrics share one universe and one ground truth.
Union means "flagged by A or B". Recall gain is measured against the stronger single
signal and must be read together with the false-positive cost. Jaccard overlaps describe
agreement only; they say nothing about correctness.
"""
from __future__ import annotations

from itertools import combinations

from .metrics import confusion, rates
from .normalize import Dataset

COMP_COLUMNS = ["analysis", "signal_a", "signal_b", "signal_type_a", "signal_type_b", "status",
                "n_malicious", "n_benign", "recall_a", "recall_b", "recall_union", "recall_gain",
                "fpr_a", "fpr_b", "fpr_union", "fpr_increase_over_a", "fpr_increase_over_b",
                "precision_a", "precision_b", "precision_union", "f1_a", "f1_b", "f1_union",
                "jaccard_positive_sets", "tp_both", "tp_unique_a", "tp_unique_b",
                "fp_both", "fp_unique_a", "fp_unique_b", "note"]


def _sub(a, b):
    return None if a is None or b is None else a - b


def pairwise_rows(ds: Dataset, pids: list[str], analysis: str = "primary") -> list[dict]:
    sigs = [s for s, c in ds.signals.items() if c.get("include_in_pairs", False)]
    rows = []
    for a, b in combinations(sigs, 2):
        base = {"analysis": analysis, "signal_a": a, "signal_b": b,
                "signal_type_a": ds.signals[a].get("signal_type", ""),
                "signal_type_b": ds.signals[b].get("signal_type", "")}
        if not (ds.signal_has_data(a) and ds.signal_has_data(b)):
            rows.append({**base, "status": "unavailable",
                         "note": "one or both signals have no usable tool runs; no pair constructed"})
            continue
        u = [p for p in pids if ds.verdict(a, p) is not None and ds.verdict(b, p) is not None]
        t = [ds.truth(p) for p in u]
        pa = [ds.verdict(a, p) for p in u]
        pb = [ds.verdict(b, p) for p in u]
        pu = [1 if (x or y) else 0 for x, y in zip(pa, pb)]
        ra, rb, ru = (rates(confusion(t, v)) for v in (pa, pb, pu))
        inter = sum(1 for x, y in zip(pa, pb) if x and y)
        union = sum(1 for x, y in zip(pa, pb) if x or y)
        tp_both = sum(1 for x, y, z in zip(pa, pb, t) if x and y and z)
        tp_a = sum(1 for x, y, z in zip(pa, pb, t) if x and not y and z)
        tp_b = sum(1 for x, y, z in zip(pa, pb, t) if y and not x and z)
        fp_both = sum(1 for x, y, z in zip(pa, pb, t) if x and y and not z)
        fp_a = sum(1 for x, y, z in zip(pa, pb, t) if x and not y and not z)
        fp_b = sum(1 for x, y, z in zip(pa, pb, t) if y and not x and not z)
        gain = None
        if ru["recall"] is not None and ra["recall"] is not None and rb["recall"] is not None:
            gain = ru["recall"] - max(ra["recall"], rb["recall"])
        note = []
        if len(u) < len(pids):
            note.append(f"{len(pids) - len(u)} package(s) dropped: a signal had no usable verdict")
        rows.append({**base, "status": "ok", "n_malicious": sum(t), "n_benign": len(t) - sum(t),
                     "recall_a": ra["recall"], "recall_b": rb["recall"], "recall_union": ru["recall"],
                     "recall_gain": gain, "fpr_a": ra["fpr"], "fpr_b": rb["fpr"], "fpr_union": ru["fpr"],
                     "fpr_increase_over_a": _sub(ru["fpr"], ra["fpr"]),
                     "fpr_increase_over_b": _sub(ru["fpr"], rb["fpr"]),
                     "precision_a": ra["precision"], "precision_b": rb["precision"],
                     "precision_union": ru["precision"], "f1_a": ra["f1"], "f1_b": rb["f1"],
                     "f1_union": ru["f1"],
                     "jaccard_positive_sets": (inter / union) if union else None,
                     "tp_both": tp_both, "tp_unique_a": tp_a, "tp_unique_b": tp_b,
                     "fp_both": fp_both, "fp_unique_a": fp_a, "fp_unique_b": fp_b,
                     "note": "; ".join(note)})
    return rows


def jaccard(a: set, b: set) -> float | None:
    """Jaccard index; undefined (None) when both sets are empty."""
    u = a | b
    return (len(a & b) / len(u)) if u else None
