"""CSV and YAML helpers. Plain csv module; outputs are deterministic and pandas/R friendly."""
from __future__ import annotations

import csv
import hashlib
import math
from pathlib import Path
from typing import Any, Iterable

import yaml

from .schemas import ValidationError

NA = "NA"


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_yaml(path: str | Path) -> dict:
    p = Path(path)
    if not p.is_file():
        raise ValidationError([f"file not found: {p}"])
    with open(p, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValidationError([f"{p}: expected a YAML mapping at top level"])
    return data


def read_table(path: str | Path, required: list[str], optional: list[str] | None = None) -> list[dict]:
    """Read a CSV, check required columns, strip whitespace, keep unknown columns out.

    Missing optional columns are filled with empty strings.
    """
    p = Path(path)
    if not p.is_file():
        raise ValidationError([f"input file not found: {p}"])
    with open(p, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        cols = reader.fieldnames or []
        missing = [c for c in required if c not in cols]
        if missing:
            raise ValidationError([f"{p.name}: missing required column(s) {missing}; found {cols}"])
        keep = list(required) + [c for c in (optional or [])]
        rows = []
        for line_no, raw in enumerate(reader, start=2):
            row = {c: (raw.get(c) or "").strip() for c in keep}
            row["_line"] = line_no
            rows.append(row)
    return rows


def fmt(value: Any) -> str:
    """Format a cell: None/NaN -> NA, floats to 6 decimals, bools to true/false."""
    if value is None:
        return NA
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float):
        if math.isnan(value):
            return NA
        return f"{value:.6f}"
    return str(value)


def write_csv(path: str | Path, rows: Iterable[dict], columns: list[str]) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(columns)
        for r in rows:
            w.writerow([fmt(r.get(c)) for c in columns])
    return p


def read_output(path: str | Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def split_list(cell: str, sep: str = "|") -> list[str]:
    return [x.strip() for x in cell.split(sep) if x.strip()]
