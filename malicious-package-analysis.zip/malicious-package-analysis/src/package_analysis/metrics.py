"""Confusion-matrix metrics with an explicit undefined-value policy.

Undefined policy: a metric whose denominator is zero is ``None`` (written as ``NA``). It is
never replaced by 0. F1 is computed as 2TP / (2TP + FP + FN), which equals the harmonic mean
of precision and recall whenever both are defined and stays defined when TP = 0 but there
are errors (so a detector with no hits and some false positives has F1 = 0, not NA). F1 is
undefined only when TP = FP = FN = 0.
"""
from __future__ import annotations

from .normalize import Dataset

METRIC_NAMES = ("precision", "recall", "f1", "fpr", "fnr", "accuracy")


def _div(a: float, b: float) -> float | None:
    return None if b == 0 else a / b


def confusion(truth: list[int], pred: list[int | None]) -> dict:
    """Count TP/FP/TN/FN; ``None`` predictions are reported as ``unknown`` and not scored."""
    tp = fp = tn = fn = unk = 0
    for t, p in zip(truth, pred):
        if p is None:
            unk += 1
        elif t == 1 and p == 1:
            tp += 1
        elif t == 0 and p == 1:
            fp += 1
        elif t == 0 and p == 0:
            tn += 1
        else:
            fn += 1
    return {"TP": tp, "FP": fp, "TN": tn, "FN": fn, "unknown": unk}


def rates(c: dict) -> dict:
    tp, fp, tn, fn = c["TP"], c["FP"], c["TN"], c["FN"]
    return {
        "precision": _div(tp, tp + fp),
        "recall": _div(tp, tp + fn),
        "f1": _div(2 * tp, 2 * tp + fp + fn),
        "fpr": _div(fp, fp + tn),
        "fnr": _div(fn, fn + tp),
        "accuracy": _div(tp + tn, tp + fp + tn + fn),
    }


def evaluate(ds: Dataset, signal: str, pids: list[str]) -> dict:
    truth = [ds.truth(p) for p in pids]
    pred = ds.signal_vector(signal, pids)
    c = confusion(truth, pred)
    r = rates(c)
    n_mal = c["TP"] + c["FN"]
    n_ben = c["FP"] + c["TN"]
    return {**c, **r, "n_malicious_evaluated": n_mal, "n_benign_evaluated": n_ben,
            "n_malicious_total": sum(truth), "n_benign_total": len(truth) - sum(truth)}


def package_metric_rows(ds: Dataset, pids: list[str], analysis: str = "primary") -> tuple[list[dict], list[dict]]:
    """Return (package_metrics rows, confusion_matrices rows) for every signal with data."""
    pm, cm = [], []
    for name, s in ds.signals.items():
        if not ds.signal_has_data(name):
            continue
        e = evaluate(ds, name, pids)
        base = {"analysis": analysis, "signal": name, "tool": s["tool"],
                "signal_type": s.get("signal_type", ""),
                "negative_control": bool(s.get("negative_control", False))}
        cm.append({**base, "TP": e["TP"], "FP": e["FP"], "TN": e["TN"], "FN": e["FN"],
                   "n_malicious_evaluated": e["n_malicious_evaluated"],
                   "n_benign_evaluated": e["n_benign_evaluated"],
                   "n_unknown_or_unrun": e["unknown"]})
        pm.append({**base, **{m: e[m] for m in METRIC_NAMES},
                   "TP": e["TP"], "FP": e["FP"], "TN": e["TN"], "FN": e["FN"],
                   "n_malicious_evaluated": e["n_malicious_evaluated"],
                   "n_benign_evaluated": e["n_benign_evaluated"],
                   "n_unknown_or_unrun": e["unknown"]})
    return pm, cm


PM_COLUMNS = ["analysis", "signal", "tool", "signal_type", "negative_control", "precision", "recall", "f1",
              "fpr", "fnr", "accuracy", "TP", "FP", "TN", "FN", "n_malicious_evaluated",
              "n_benign_evaluated", "n_unknown_or_unrun"]
CM_COLUMNS = ["analysis", "signal", "tool", "signal_type", "negative_control", "TP", "FP", "TN", "FN",
              "n_malicious_evaluated", "n_benign_evaluated", "n_unknown_or_unrun"]
