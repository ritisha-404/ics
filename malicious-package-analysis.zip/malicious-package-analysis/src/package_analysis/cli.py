"""Command line interface: validate, run, report, cluster."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .schemas import ValidationError


def _cmd_validate(a: argparse.Namespace) -> int:
    from .normalize import load_dataset
    ds = load_dataset(a.config)
    print(f"OK: {len(ds.included)} included package(s), {len(ds.exclusions)} excluded, "
          f"{len(ds.findings)} finding(s), {len(ds.labels)} annotation(s).")
    for w in ds.warnings:
        print(f"warning: {w}")
    return 0


def _cmd_run(a: argparse.Namespace) -> int:
    from .pipeline import run
    out = Path(a.output_dir)
    cfg_out = out / "effective_config.yaml"
    res = run(a.config, out, test_mode=a.test_mode)
    import shutil
    shutil.copyfile(a.config, cfg_out)
    print(json.dumps(res, indent=2))
    return 0


def _cmd_report(a: argparse.Namespace) -> int:
    from .report import write_summary
    if not (Path(a.input) / "experiment_manifest.json").is_file():
        raise ValidationError([f"{a.input}: no experiment_manifest.json; run `package-analysis run` first"])
    print(write_summary(a.input))
    return 0


def _cmd_cluster(a: argparse.Namespace) -> int:
    from . import io
    from .deduplication import cluster_directory
    m = cluster_directory(a.artifacts_dir)
    io.write_csv(a.output, [{"package_id": k, "duplicate_cluster": v} for k, v in sorted(m.items())],
                 ["package_id", "duplicate_cluster"])
    print(f"wrote {a.output} ({len(m)} packages, {len(set(m.values()))} clusters)")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="package-analysis", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("validate", help="validate inputs without computing anything")
    v.add_argument("--config", required=True)
    v.set_defaults(fn=_cmd_validate)
    r = sub.add_parser("run", help="validate, compute and write all outputs")
    r.add_argument("--config", required=True)
    r.add_argument("--output-dir", default="outputs")
    r.add_argument("--test-mode", action="store_true", help="fewer bootstrap resamples; outputs labeled as test")
    r.set_defaults(fn=_cmd_run)
    p = sub.add_parser("report", help="regenerate run_summary.md from an output directory")
    p.add_argument("--input", required=True)
    p.set_defaults(fn=_cmd_report)
    c = sub.add_parser("cluster", help="assign normalized-code clusters to unpacked package source dirs (offline, no execution)")
    c.add_argument("--artifacts-dir", required=True)
    c.add_argument("--output", required=True)
    c.set_defaults(fn=_cmd_cluster)
    a = ap.parse_args(argv)
    try:
        return a.fn(a)
    except ValidationError as e:
        print("error: input validation failed", file=sys.stderr)
        for pr in e.problems[:50]:
            print(f"  - {pr}", file=sys.stderr)
        if len(e.problems) > 50:
            print(f"  ... and {len(e.problems) - 50} more", file=sys.stderr)
        return 2
    except (OSError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
