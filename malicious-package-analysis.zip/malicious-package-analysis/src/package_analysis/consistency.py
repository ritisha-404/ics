"""Checks of the paper's reported numbers: internal arithmetic and comparison with recomputed values.

Status values: consistent, minor_difference (bootstrap CI endpoints within 0.01), inconsistent,
not_available (nothing to compare against), note (observation, no comparison).
"""
from __future__ import annotations

from pathlib import Path

from . import io

CC_COLUMNS = ["check_id", "category", "item", "reported", "recomputed", "difference", "tolerance", "status", "note"]


def _row(cid, cat, item, rep, rec, tol, note="", minor=None):
    """Compare two numbers. ``minor`` (optional) is a looser tolerance that yields 'minor_difference'."""
    if rep is None and rec is None and note == "reported N/A":
        return {"check_id": cid, "category": cat, "item": item, "reported": None, "recomputed": None,
                "difference": None, "tolerance": tol, "status": "consistent", "note": "N/A in both"}
    if rep is None or rec is None:
        return {"check_id": cid, "category": cat, "item": item, "reported": rep, "recomputed": rec,
                "difference": None, "tolerance": tol, "status": "not_available", "note": note}
    d = rec - rep
    status = "consistent" if abs(d) <= tol else ("minor_difference" if minor is not None and abs(d) <= minor else "inconsistent")
    return {"check_id": cid, "category": cat, "item": item, "reported": rep, "recomputed": rec,
            "difference": d, "tolerance": tol, "status": status, "note": note}


def internal_checks(ref: dict) -> list[dict]:
    """Arithmetic that only needs the paper's own numbers."""
    rows, k = [], 0
    n_mal, n_ben = ref["text"]["n_malicious"], ref["text"]["n_benign"]
    for sig, v in ref["table_ii"].items():
        p, r, f = v["precision"], v["recall"], v["f1"]
        k += 1
        rows.append(_row(f"I{k:02d}", "internal_f1", f"{sig}: F1 from reported precision and recall",
                         f, (2 * p * r / (p + r)) if (p + r) else 0.0, 0.0015,
                         "tolerance covers rounding of three-decimal inputs"))
        # precision implied by recall, FPR and the stated class sizes
        tp, fp = r * n_mal, v["fpr"] * n_ben
        k += 1
        rows.append(_row(f"I{k:02d}", "internal_precision", f"{sig}: precision implied by recall, FPR, 122/103",
                         p, (tp / (tp + fp)) if (tp + fp) else None, 0.004,
                         "TP = recall*122, FP = FPR*103"))
    for b, v in ref["table_iii"].items():
        mx = max(x for x in (v["bandit"], v["guarddog"]) if x is not None)
        k += 1
        rows.append({"check_id": f"I{k:02d}", "category": "internal_union_bound",
                     "item": f"{b}: union rate >= largest single-tool rate", "reported": v["union"],
                     "recomputed": mx, "difference": v["union"] - mx, "tolerance": 0.0005,
                     "status": "consistent" if v["union"] >= mx - 0.0005 else "inconsistent",
                     "note": "a union cannot be lower than its largest component"})
    for key, (num, den, dec) in ref["text"]["abstract_fractions"].items():
        k += 1
        rows.append(_row(f"I{k:02d}", "internal_fraction", f"{key}: {num}/{den} vs stated {dec}", dec, num / den, 0.0006))
    d = ref["text"]["dedup"]
    k += 1
    rows.append(_row(f"I{k:02d}", "internal_dedup", "dedup: 130-8 candidates -> 122 -> 74 (48 removed)",
                     float(ref["text"]["n_malicious"] - d["n_malicious"]), 48.0, 0.0))
    k += 1
    rows.append(_row(f"I{k:02d}", "internal_dedup", "dedup GuardDog recall 0.959 = 71/74",
                     d["guarddog_recall"], 71 / 74, 0.0006))
    for key in ("B4_guarddog", "B7_guarddog"):
        n1, d1, n2, d2 = d[key]
        k += 1
        rows.append({"check_id": f"I{k:02d}", "category": "internal_note",
                     "item": f"dedup {key}: numerators {n1} -> {n2}", "reported": None, "recomputed": None,
                     "difference": None, "tolerance": None, "status": "note",
                     "note": "B4 and B7 share identical numerators (53 -> 12) in both analyses; possible but "
                             "confirm against the label files (the data_checks rows below do this when data are real)"})
    return rows


def data_checks(ref: dict, pm: list[dict], boot: list[dict], cov: list[dict], pairs: list[dict],
                dup: list[dict]) -> list[dict]:
    rows, k = [], 0
    pmi = {r["signal"]: r for r in pm if r["analysis"] == "primary"}
    bi = {(r["signal"], r["metric"]): r for r in boot if r["analysis"] == "primary" and r["method"] == "package"}
    for sig, v in ref["table_ii"].items():
        r = pmi.get(sig)
        for m in ("precision", "recall", "f1", "fpr"):
            k += 1
            rows.append(_row(f"D{k:03d}", "table_ii", f"{sig} {m}", v[m], None if r is None else r[m], 0.0006))
        for m in ("recall", "f1", "fpr"):
            b = bi.get((sig, m))
            for j, end in enumerate(("ci_low", "ci_high")):
                k += 1
                rows.append(_row(f"D{k:03d}", "table_ii_ci", f"{sig} {m} {end}", v[f"{m}_ci"][j],
                                 None if b is None else b[end], 0.003,
                                 "depends on bootstrap implementation details (resampling unit, percentile rule, RNG)",
                                 minor=0.01))
    ci = {(r["analysis"], r["signal"], r["behavior_id"]): r for r in cov}
    for b, v in ref["table_iii"].items():
        for sig, key in (("bandit", "bandit"), ("guarddog", "guarddog"), ("union", "union")):
            r = ci.get(("primary", sig, b))
            rec = None if r is None or r.get("applicability") != "applicable" else r.get("detection_rate")
            k += 1
            rows.append(_row(f"D{k:03d}", "table_iii", f"{b} {sig} rate", v[key], rec, 0.0006,
                             "reported N/A" if v[key] is None else ""))
        r = ci.get(("primary", "guarddog", b))
        k += 1
        rows.append(_row(f"D{k:03d}", "table_iii_n", f"{b} labeled instances", float(v["n"]),
                         None if r is None else float(r["n_confirmed_positive"]), 0.0))
    pi = {(r["signal_a"], r["signal_b"]): r for r in pairs if r["analysis"] == "primary" and r["status"] == "ok"}
    for p in ref["text"]["pairs"]:
        r = pi.get((p["a"], p["b"])) or pi.get((p["b"], p["a"]))
        for key, col in (("recall_union", "recall_union"), ("gain", "recall_gain"), ("fpr_union", "fpr_union")):
            k += 1
            rows.append(_row(f"D{k:03d}", "pairs", f"{p['a']}+{p['b']} {key}", p[key], None if r is None else r[col], 0.0006))
    dd = {(r["section"], r.get("signal") or "", r["key"]): r for r in dup}
    d = ref["text"]["dedup"]
    for key, rep in (("n_malicious", d["n_malicious"]), ("n_benign", d["n_benign"]), ("n_total", d["n_total"])):
        r = dd.get(("composition", "", key))
        k += 1
        rows.append(_row(f"D{k:03d}", "dedup", key, float(rep), None if r is None else float(r["dedup_value"]), 0.0))
    for item, sec, sig, key, rep in (("guarddog recall", "package_metric", "guarddog", "recall", d["guarddog_recall"]),
                                      ("guarddog fpr", "package_metric", "guarddog", "fpr", d["guarddog_fpr"])):
        r = dd.get((sec, sig, key))
        k += 1
        rows.append(_row(f"D{k:03d}", "dedup", item, rep, None if r is None else r["dedup_value"], 0.0006))
    for bk, b in (("B4_guarddog", "B4"), ("B7_guarddog", "B7")):
        r = dd.get(("behavior_rate", "guarddog", b))
        n1, d1, n2, d2 = d[bk]
        for lab, rep, col in (("full numerator", n1, "primary_numerator"), ("full denominator", d1, "primary_denominator"),
                              ("dedup numerator", n2, "dedup_numerator"), ("dedup denominator", d2, "dedup_denominator")):
            k += 1
            rows.append(_row(f"D{k:03d}", "dedup", f"{b} guarddog {lab}", float(rep),
                             None if r is None or r.get(col) is None else float(r[col]), 0.0))
    return rows
