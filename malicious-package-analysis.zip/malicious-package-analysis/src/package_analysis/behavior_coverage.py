"""Behavior-level detection coverage (paper eq. 5 and 6).

Unit: a labeled behavior instance = (package, behavior) with annotation_status
``confirmed_positive`` in the analysis universe. Denominators therefore differ by behavior
and are not unique-package counts.

* n_confirmed_positive : instances in the universe
* n_unknown_annotation : (package, behavior) pairs annotated ``unknown`` (not scored)
* n_evaluated          : positives for which the tool has a usable (ok) run
* n_detected / n_missed: among evaluated, tool did / did not report a mapped finding
* A tool that is not applicable to a behavior gets status ``N/A`` and no rate (never 0).
* Package-level feed matches and capability-only signals have no behavior_categories and
  never appear here. A miss means "no static finding", not "behavior absent".
"""
from __future__ import annotations

from .normalize import Dataset
from .schemas import BEHAVIORS

COV_COLUMNS = ["analysis", "behavior_id", "behavior_name", "signal", "applicability", "n_confirmed_positive",
               "n_unknown_annotation", "n_evaluated", "n_detected", "n_missed", "n_unevaluable_run_missing",
               "detection_rate", "status", "note"]


def behavior_signals(ds: Dataset) -> list[str]:
    return [s for s, c in ds.signals.items() if c.get("behavior_categories")]


def applicable(ds: Dataset, signal: str, b: str) -> bool:
    tool = ds.signals[signal]["tool"]
    spec = (ds.mapping.get("tools") or {}).get(tool) or {}
    return b in (spec.get("applicable_behaviors") or [])


def _status(n: int, low: int, very_low: int) -> str:
    if n < very_low:
        return "very_low_sample"
    if n < low:
        return "low_sample"
    return "ok"


def coverage_rows(ds: Dataset, pids: list[str], analysis: str = "primary") -> list[dict]:
    cov_cfg = ds.config.get("behavior_coverage", {})
    low = int(cov_cfg.get("low_sample_threshold", 10))
    very_low = int(cov_cfg.get("very_low_sample_threshold", 3))
    pos = ds.positives(pids)
    unk = ds.unknown_labels(pids)
    sigs = behavior_signals(ds)
    hits = {(s, p): ds.behavior_hits(s, p) for s in sigs for p in pids}
    rows = []
    for b, name in BEHAVIORS.items():
        inst = sorted(p for p in pids if b in pos.get(p, set()))
        n_pos = len(inst)
        app = [s for s in sigs if applicable(ds, s, b)]
        for s in sigs:
            base = {"analysis": analysis, "behavior_id": b, "behavior_name": name, "signal": s,
                    "n_confirmed_positive": n_pos, "n_unknown_annotation": unk.get(b, 0)}
            if s not in app:
                rows.append({**base, "applicability": "not_applicable", "status": "N/A",
                             "note": "tool not mapped to this behavior; no rate reported (not zero)"})
                continue
            ev = [p for p in inst if hits[(s, p)] is not None]
            det = [p for p in ev if b in hits[(s, p)]]
            rows.append({**base, "applicability": "applicable", "n_evaluated": len(ev), "n_detected": len(det),
                         "n_missed": len(ev) - len(det), "n_unevaluable_run_missing": n_pos - len(ev),
                         "detection_rate": (len(det) / len(ev)) if ev else None,
                         "status": _status(len(ev), low, very_low) if ev else "no_evaluable_instances",
                         "note": ""})
        # union over applicable behavior-reporting signals
        ub = {"analysis": analysis, "behavior_id": b, "behavior_name": name, "signal": "union",
              "n_confirmed_positive": n_pos, "n_unknown_annotation": unk.get(b, 0)}
        if not app:
            rows.append({**ub, "applicability": "not_applicable", "status": "N/A",
                         "note": "no applicable behavior-reporting signal"})
            continue
        ev = [p for p in inst if any(hits[(s, p)] is not None for s in app)]
        det = [p for p in ev if any(hits[(s, p)] is not None and b in hits[(s, p)] for s in app)]
        note = "union of " + ",".join(app) + ("; single applicable tool" if len(app) == 1 else "")
        rows.append({**ub, "applicability": "applicable", "n_evaluated": len(ev), "n_detected": len(det),
                     "n_missed": len(ev) - len(det), "n_unevaluable_run_missing": n_pos - len(ev),
                     "detection_rate": (len(det) / len(ev)) if ev else None,
                     "status": _status(len(ev), low, very_low) if ev else "no_evaluable_instances",
                     "note": note})
    return rows
