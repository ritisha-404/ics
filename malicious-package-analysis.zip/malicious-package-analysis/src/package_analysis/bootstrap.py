"""Seeded percentile bootstrap for package-level metrics.

What is resampled
-----------------
``package`` method (default, matches the paper): the unit is a package. Each replicate draws
N packages with replacement from the N included packages (not stratified by label), so the
number of malicious and benign packages varies between replicates. The same drawn
multiset is used for every metric and every signal in a replicate.

``cluster`` method (sensitivity analysis, not in the paper): the unit is a duplicate
cluster. Packages sharing ``duplicate_cluster`` are drawn together; packages without a
cluster id are their own cluster. Use it when related samples are not independent.

Undefined replicates
--------------------
If a metric's denominator is zero in a replicate (e.g. no benign package drawn, so FPR is
undefined), that replicate is omitted for that metric only. ``n_valid`` reports how many
replicates contributed. Percentiles use numpy's default linear interpolation.

A degenerate interval (low == high), as for a zero false-positive count, only says the
resamples all had the same value. It is not evidence of zero uncertainty.
"""
from __future__ import annotations

import numpy as np

from .metrics import METRIC_NAMES
from .normalize import Dataset

BOOT_COLUMNS = ["analysis", "method", "signal", "metric", "estimate", "ci_low", "ci_high",
                "n_resamples", "n_valid", "seed", "degenerate_interval", "n_units"]


def _weights(rng: np.random.Generator, n_units: int, n_boot: int, membership: np.ndarray | None) -> np.ndarray:
    """Return an (n_boot, n_packages) matrix of draw counts."""
    idx = rng.integers(0, n_units, size=(n_boot, n_units))
    w = np.zeros((n_boot, n_units), dtype=np.float64)
    rows = np.repeat(np.arange(n_boot), n_units)
    np.add.at(w, (rows, idx.ravel()), 1.0)
    return w if membership is None else w @ membership


def _metric_arrays(tp, fp, tn, fn) -> dict[str, np.ndarray]:
    def div(a, b):
        out = np.full(a.shape, np.nan)
        np.divide(a, b, out=out, where=b > 0)
        return out
    return {"precision": div(tp, tp + fp), "recall": div(tp, tp + fn),
            "f1": div(2 * tp, 2 * tp + fp + fn), "fpr": div(fp, fp + tn),
            "fnr": div(fn, fn + tp), "accuracy": div(tp + tn, tp + fp + tn + fn)}


def bootstrap_rows(ds: Dataset, pids: list[str], point: dict[str, dict], analysis: str = "primary",
                   method: str = "package", n_boot: int | None = None, seed: int | None = None) -> list[dict]:
    """``point`` maps signal -> metrics dict from metrics.evaluate (for point estimates)."""
    cfg = ds.config.get("bootstrap", {})
    n_boot = int(n_boot if n_boot is not None else cfg.get("n_resamples", 2000))
    seed = int(seed if seed is not None else cfg.get("seed", 42))
    n = len(pids)
    rng = np.random.default_rng(seed)
    membership = None
    n_units = n
    if method == "cluster":
        cl = [ds.included[p]["duplicate_cluster"] or f"__single__{p}" for p in pids]
        keys = sorted(set(cl))
        col = {k: i for i, k in enumerate(keys)}
        membership = np.zeros((len(keys), n))
        for j, k in enumerate(cl):
            membership[col[k], j] = 1.0
        n_units = len(keys)
    elif method != "package":
        raise ValueError(f"unknown bootstrap method '{method}'")
    w = _weights(rng, n_units, n_boot, membership)
    truth = np.array([ds.truth(p) for p in pids], dtype=np.float64)
    rows = []
    for sig in point:
        pred = ds.signal_vector(sig, pids)
        known = np.array([p is not None for p in pred], dtype=np.float64)
        pv = np.array([0 if p is None else p for p in pred], dtype=np.float64)
        tp = w @ (known * truth * pv)
        fp = w @ (known * (1 - truth) * pv)
        fn = w @ (known * truth * (1 - pv))
        tn = w @ (known * (1 - truth) * (1 - pv))
        arrs = _metric_arrays(tp, fp, tn, fn)
        for m in METRIC_NAMES:
            vals = arrs[m][~np.isnan(arrs[m])]
            est = point[sig][m]
            if len(vals):
                lo, hi = (float(x) for x in np.percentile(vals, [2.5, 97.5]))
            else:
                lo = hi = None
            rows.append({"analysis": analysis, "method": method, "signal": sig, "metric": m,
                         "estimate": est, "ci_low": lo, "ci_high": hi, "n_resamples": n_boot,
                         "n_valid": int(len(vals)), "seed": seed,
                         "degenerate_interval": (lo is not None and lo == hi),
                         "n_units": n_units})
    return rows
