"""Offline evaluation pipeline for malicious Python package detector outputs."""
__version__ = "0.1.0"
