"""Near-duplicate sensitivity analysis.

Cluster assignments come from the manifest column ``duplicate_cluster`` (supplied) or from
``cluster_directory`` (documented offline procedure below). Package names alone are never
used as evidence of duplication.

Documented clustering procedure (``normalized_code_hash`` / ``cluster_directory``)
  1. Read every ``.py`` file under a package directory as text (nothing is imported or run).
  2. Drop comment-only lines, collapse whitespace, lower-case, replace the package name and
     all digit runs with fixed tokens.
  3. Sort files by relative path, concatenate, SHA-256 the result; the first 10 hex digits
     are the cluster id. Identical normalized code gives identical ids.
Exact normalized-code equality is conservative: it misses paraphrased or lightly edited
variants, so it will under-merge compared with fuzzy clustering.

Representative selection: within each cluster the package with the lexicographically
smallest ``package_id`` is retained (deterministic, independent of file order). Benign
packages are retained unchanged unless ``deduplication.cluster_benign`` is true.
"""
from __future__ import annotations

import hashlib
import re
from collections import Counter
from pathlib import Path

from .behavior_coverage import coverage_rows
from .metrics import METRIC_NAMES, evaluate
from .normalize import Dataset

DUP_COLUMNS = ["section", "signal", "key", "primary_value", "dedup_value", "delta",
                "primary_numerator", "primary_denominator", "dedup_numerator", "dedup_denominator", "note"]


def normalized_code_hash(files: dict[str, str], package_name: str = "") -> str:
    parts = []
    for rel in sorted(files):
        lines = []
        for ln in files[rel].splitlines():
            s = ln.strip()
            if not s or s.startswith("#"):
                continue
            lines.append(re.sub(r"\s+", " ", s).lower())
        text = "\n".join(lines)
        if package_name:
            text = text.replace(package_name.lower(), "<pkg>")
        parts.append(re.sub(r"\d+", "<n>", text))
    return hashlib.sha256("\n--file--\n".join(parts).encode("utf-8")).hexdigest()[:10]


def cluster_directory(root: str | Path) -> dict[str, str]:
    """Map each immediate sub-directory name (package_id) to a normalized-code cluster id."""
    root = Path(root)
    out = {}
    for d in sorted(p for p in root.iterdir() if p.is_dir()):
        files = {}
        for f in sorted(d.rglob("*.py")):
            if f.is_file():
                files[str(f.relative_to(d))] = f.read_text(encoding="utf-8", errors="replace")
        out[d.name] = normalized_code_hash(files, d.name)
    return out


def has_clusters(ds: Dataset) -> bool:
    return any(r["duplicate_cluster"] for r in ds.included.values() if r["label"] == "malicious")


def select_representatives(ds: Dataset) -> tuple[list[str], list[dict]]:
    cluster_benign = bool(ds.config.get("deduplication", {}).get("cluster_benign", False))
    groups: dict[str, list[str]] = {}
    keep: list[str] = []
    for pid in sorted(ds.included):
        r = ds.included[pid]
        c = r["duplicate_cluster"]
        if c and (r["label"] == "malicious" or cluster_benign):
            groups.setdefault(f"{r['label']}:{c}", []).append(pid)
        else:
            keep.append(pid)
    removed = []
    for key, members in sorted(groups.items()):
        keep.append(members[0])
        for m in members[1:]:
            removed.append({"package_id": m, "cluster": key, "representative": members[0]})
    return sorted(keep), removed


def duplicate_rows(ds: Dataset, primary: list[str], dedup: list[str], removed: list[dict]) -> list[dict]:
    rows: list[dict] = []
    def lab(pids, l): return sum(1 for p in pids if ds.included[p]["label"] == l)
    clusters = {ds.included[p]["duplicate_cluster"] for p in primary
                if ds.included[p]["label"] == "malicious" and ds.included[p]["duplicate_cluster"]}
    for k, a, b in (("n_malicious", lab(primary, "malicious"), lab(dedup, "malicious")),
                    ("n_benign", lab(primary, "benign"), lab(dedup, "benign")),
                    ("n_total", len(primary), len(dedup))):
        rows.append({"section": "composition", "key": k, "primary_value": a, "dedup_value": b,
                     "delta": b - a, "note": ""})
    rows.append({"section": "composition", "key": "n_malicious_clusters", "primary_value": len(clusters),
                 "dedup_value": len(clusters), "delta": 0, "note": "clusters with an assigned id"})
    # behavior label frequency
    pp, pd = ds.positives(primary), ds.positives(dedup)
    cp = Counter(b for s in pp.values() for b in s)
    cd = Counter(b for s in pd.values() for b in s)
    for b in sorted(set(cp) | set(cd), key=lambda x: int(x[1:])):
        rows.append({"section": "behavior_label_count", "key": b, "primary_value": cp[b], "dedup_value": cd[b],
                     "delta": cd[b] - cp[b], "note": "confirmed_positive instances"})
    # package metrics
    for sig in ds.signals:
        if not ds.signal_has_data(sig):
            continue
        ea, eb = evaluate(ds, sig, primary), evaluate(ds, sig, dedup)
        for m in METRIC_NAMES:
            a, b = ea[m], eb[m]
            rows.append({"section": "package_metric", "signal": sig, "key": m, "primary_value": a,
                         "dedup_value": b, "delta": None if a is None or b is None else b - a})
    # behavior coverage
    ca = {(r["signal"], r["behavior_id"]): r for r in coverage_rows(ds, primary)}
    cb = {(r["signal"], r["behavior_id"]): r for r in coverage_rows(ds, dedup)}
    for k in ca:
        a, b = ca[k], cb[k]
        if a["applicability"] != "applicable":
            continue
        ra, rb = a.get("detection_rate"), b.get("detection_rate")
        rows.append({"section": "behavior_rate", "signal": k[0], "key": k[1], "primary_value": ra,
                     "dedup_value": rb, "delta": None if ra is None or rb is None else rb - ra,
                     "primary_numerator": a.get("n_detected"), "primary_denominator": a.get("n_evaluated"),
                     "dedup_numerator": b.get("n_detected"), "dedup_denominator": b.get("n_evaluated"),
                     "note": b.get("status", "")})
    return rows
