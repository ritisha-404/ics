#!/usr/bin/env python3
"""Convenience wrapper: python scripts/run_experiment.py [--config C] [--output-dir D] [--test-mode]."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from package_analysis.cli import main  # noqa: E402

if __name__ == "__main__":
    args = sys.argv[1:]
    if "--config" not in args:
        args = ["--config", str(Path(__file__).resolve().parents[1] / "config" / "experiment.yaml")] + args
    raise SystemExit(main(["run"] + args))
