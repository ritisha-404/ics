#!/usr/bin/env python3
"""Convert the outputs of this project's earlier ad-hoc pipeline into the package_analysis schemas.

This is an adapter, not part of the analysis engine. It reads only CSVs (no package code).
Nothing is invented: fields the earlier pipeline did not record are left empty, and Bandit
rule ids (which it did not retain) are represented by one aggregate finding per flagged
package whose behaviors were mapped upstream (``adapter_behaviors``).

Usage:
  python scripts/convert_prior_pipeline.py PRIOR_PROJECT_DIR OUT_DIR \
      --tool-version guarddog=3.2.0 --tool-version bandit=1.9.4
"""
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

TOOL_NAMES = {"guarddog": "guarddog", "bandit": "bandit", "osv_mal": "osv_malicious_feed", "osv_vuln": "osv_scanner"}
CUSTOM = {"osv_malicious_feed": "custom_offline_matcher_over_ossf_malicious_packages_clone",
          "osv_scanner": "custom_offline_matcher_over_github_advisory_database_clone"}
TOKEN = re.compile(r"[A-Za-z0-9+/=_\-]{36,}")


def clean(text: str, n: int = 300) -> str:
    text = TOKEN.sub("<token>", text.replace("\r", " ").replace("\n", " "))
    return text[:n]


def rd(p: Path) -> list[dict]:
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def wr(p: Path, rows: list[dict], cols: list[str]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("prior_dir")
    ap.add_argument("out_dir")
    ap.add_argument("--tool-version", action="append", default=[], help="tool=version as installed (not captured per run)")
    a = ap.parse_args()
    src, out = Path(a.prior_dir), Path(a.out_dir)
    versions = dict(x.split("=", 1) for x in a.tool_version)
    ds = rd(src / "data/dataset.csv")
    pid = lambda r: f"{r['package']}=={r['version']}"

    manifest = []
    for r in ds:
        manifest.append({
            "package_id": pid(r), "package_name": r["package"], "version": r["version"], "label": r["label"],
            "source": r["source"], "sha256": r["sha256"], "duplicate_cluster": r["family"],
            "data_origin": "real",
            "exclusion_reason": "no observable behavior label could be assigned" if r["exclude"] == "1" else "",
            "notes": r["notes"]})
    wr(out / "package_manifest.csv", manifest,
       ["package_id", "package_name", "version", "label", "source", "sha256", "duplicate_cluster", "data_origin",
        "exclusion_reason", "notes"])

    runs, findings = [], []
    seen_run = set()
    for prior, tool in TOOL_NAMES.items():
        for r in rd(src / f"results/tool_outputs_{prior}.csv"):
            k = (pid(r), tool)
            if k in seen_run:
                continue
            seen_run.add(k)
            status = "unavailable" if r["verdict"] == "no_data" else "ok"
            ver = versions.get(tool, CUSTOM.get(tool, ""))
            runs.append({"package_id": k[0], "tool": tool, "tool_version": ver, "executed_at": "",
                         "run_status": status, "rule_set_version": ""})
            if status != "ok" or r["verdict"] != "suspicious":
                continue
            if prior == "bandit":
                findings.append({"package_id": k[0], "tool": tool, "finding_id": "bandit:aggregate",
                                 "rule_id": "aggregate_rule_ids_not_retained", "finding_category": "code_analysis",
                                 "raw_evidence": "Bandit flagged this package; per-test ids were not retained by the earlier pipeline",
                                 "evidence_source": "prior pipeline tool_outputs_bandit.csv",
                                 "adapter_behaviors": r["behaviors"]})
            elif prior in ("osv_mal", "osv_vuln"):
                for adv in [x for x in r["advisory_ids"].split("|") if x]:
                    findings.append({"package_id": k[0], "tool": tool, "finding_id": f"{tool}:{adv}", "rule_id": adv,
                                     "finding_category": "feed_match" if prior == "osv_mal" else "vulnerability",
                                     "raw_evidence": adv, "evidence_source": f"prior pipeline tool_outputs_{prior}.csv",
                                     "adapter_behaviors": ""})
    for r in rd(src / "results/evidence_guarddog.csv"):
        findings.append({"package_id": pid(r), "tool": "guarddog", "finding_id": f"guarddog:{r['rule']}",
                         "rule_id": r["rule"], "finding_category": r["kind"],
                         "raw_evidence": f"n_hits={r['n_hits']}; " + clean(r["evidence"]),
                         "evidence_source": "guarddog JSON (evidence_guarddog.csv), truncated and token-masked",
                         "adapter_behaviors": ""})
    wr(out / "tool_runs.csv", runs, ["package_id", "tool", "tool_version", "executed_at", "run_status", "rule_set_version"])
    wr(out / "findings.csv", findings, ["package_id", "tool", "finding_id", "rule_id", "finding_category",
                                         "raw_evidence", "evidence_source", "adapter_behaviors"])

    ev = {}
    for r in rd(src / "data/label_evidence.csv"):
        ev.setdefault((f"{r['package']}=={r['version']}", r["behavior"]), clean(r["evidence"], 200))
    labels = []
    for r in ds:
        if r["label"] == "malicious":
            for b in [x for x in r["behaviors"].split("|") if x]:
                labels.append({"package_id": pid(r), "behavior_id": b, "annotation_status": "confirmed_positive",
                               "evidence_ref": ev.get((pid(r), b), ""), "annotator": "rule_based_annotator_v1",
                               "notes": "automated regex annotation; limited manual validation; no second annotator"})
        else:
            for b in [x for x in r["capabilities"].split("|") if x]:
                labels.append({"package_id": pid(r), "behavior_id": b, "annotation_status": "capability_only",
                               "evidence_ref": ev.get((pid(r), b), ""), "annotator": "rule_based_annotator_v1",
                               "notes": "capability observed in benign package; no malicious intent established"})
    wr(out / "behavior_labels.csv", labels, ["package_id", "behavior_id", "annotation_status", "evidence_ref", "annotator", "notes"])
    print(f"manifest={len(manifest)} runs={len(runs)} findings={len(findings)} labels={len(labels)}")


if __name__ == "__main__":
    main()
