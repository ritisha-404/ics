# package-analysis

Offline evaluation pipeline for the study "An Empirical Analysis of Systematic Blind Spots in Open Source Malicious Package Detection" (PyPI). It consumes previously collected tool outputs and ground-truth labels and produces package-level metrics, bootstrap intervals, behavior-level coverage, pairwise complementarity and a duplicate-sensitivity analysis. It never installs, imports or runs package code.

Read first: [METHODOLOGY_AUDIT.md](METHODOLOGY_AUDIT.md) (critique, novelty assessment, missing resources) and [DEVIATIONS.md](DEVIATIONS.md) (every difference from the paper, with status labels).

## Research problem

Aggregate recall hides what a detector misses. The paper separates package-level signals (a feed match, a capability rule output, a vulnerability match) from behavior-level evidence (a finding that supports a labeled behavior B1 to B12), and asks where tools fail, how much of that is the gap between a sensitive capability and malicious intent, and what combining tools buys in recall versus false positives.

## Install and run

```bash
pip install -e ".[test]"
python -m package_analysis validate --config config/experiment.yaml
python -m package_analysis run      --config config/experiment.yaml --output-dir outputs/my_run
python -m package_analysis report   --input outputs/my_run          # regenerate run_summary.md
python -m pytest -q                                                  # 55 tests, no network
```

`run --test-mode` uses 200 bootstrap resamples and labels the outputs as test results. The shipped `config/experiment.yaml` points at `data/real/` (see below). `tests/fixtures/` holds a synthetic fixture with hand-worked expectations; it is rejected by default (`allow_synthetic: false`).

## Data flow

```
package_manifest.csv ─┐
tool_runs.csv ────────┤  validate ─► normalize ─► signals (flagged / not_flagged / unknown)
findings.csv ─────────┤                 │              │
behavior_labels.csv ──┤        behavior_mapping.yaml   ├─► metrics ─► bootstrap
config/*.yaml ────────┘        (finding ─► B1..B12)   ├─► behavior_coverage
                                                       ├─► complementarity
                                                       └─► deduplication (re-runs all of the above on retained IDs)
```

| Research question | Module | Output |
|---|---|---|
| RQ1 package-level differences, where behavior coverage varies | `metrics.py`, `bootstrap.py`, `behavior_coverage.py` | `package_metrics.csv`, `confusion_matrices.csv`, `bootstrap_intervals.csv`, `behavior_coverage.csv` |
| RQ2 lowest observed behavior detection rates | `behavior_coverage.py` | `behavior_coverage.csv` (numerators, denominators, `status`) |
| RQ3 extra recall from pairs and its FPR cost | `complementarity.py` | `pairwise_complementarity.csv` |
| RQ4 sensitivity to duplicates and composition | `deduplication.py` | `duplicate_sensitivity.csv`, `duplicate_removed_ids.csv`, rows with `analysis=deduplicated` |
| Provenance | `provenance.py` | `experiment_manifest.json` |
| Checking the paper's numbers | `consistency.py` | `paper_consistency.csv` |

## Input schemas

All inputs are CSV. Required columns are listed first; extra columns are ignored.

* `package_manifest.csv`: `package_id` (unique, stable), `label` (`malicious`|`benign`), `source`, `data_origin` (`real`|`synthetic`); optional `package_name`, `version`, `sha256`, `duplicate_cluster`, `exclusion_reason`, `notes`. Identity is `package_id`; name, version and hash are cross-checked (same name/version/hash under two ids, or one hash under two labels, is an error). A non-empty `exclusion_reason` removes the row from the analysis and writes it to `exclusions.csv`. Missing hashes and versions produce warnings, not silent defaults.
* `tool_runs.csv`: `package_id`, `tool`, `run_status` (`ok`|`failed`|`unavailable`); optional `tool_version`, `executed_at`, `rule_set_version`. One row per package and tool. This is what separates an observed negative (ok run, no finding) from a missing one.
* `findings.csv`: `package_id`, `tool`, `finding_id`, `rule_id`, `finding_category` (`threat`|`capability`|`feed_match`|`vulnerability`|`code_analysis`); optional `raw_evidence`, `evidence_source`, `adapter_behaviors`. Raw evidence is never rewritten by normalization.
* `behavior_labels.csv`: `package_id`, `behavior_id`, `annotation_status`; optional `evidence_ref`, `annotator`, `notes`.

Annotation statuses: `confirmed_positive` (behavior established), `confirmed_negative` (established absent), `unknown` (annotator looked, could not decide), `capability_only` (capability seen, no malicious intent established). A missing row means unannotated and is never read as a negative. Only `confirmed_positive` rows are scored as labeled instances.

## Normalization and behavior mapping

A signal (config `signals`) is a tool plus the finding categories that count as a package-level positive. Verdict: `flagged` (ok run and at least one such finding), `not_flagged` (ok run, none), `unknown` (no ok run; excluded from that signal's metrics and reported as `n_unknown_or_unrun`). One tool can back several signals: GuardDog backs `guarddog` (threat rules) and `guarddog_capability` (any rule).

`config/behavior_mapping.yaml` maps each tool's `rule_id` to behaviors with a rationale and lists the behaviors each tool is applicable to (Bandit: B4, B6, B7, B8; GuardDog: all twelve; feeds and vulnerability scanners: none). `behavior_categories` in a signal says which finding categories count as behavior evidence; the GuardDog capability output and OSV signals have none, so they never appear in behavior coverage. A finding that maps to nothing stays in the data and is listed in `unmapped_findings.csv` with a reason (`rule_not_in_mapping` or `no_behavior_in_taxonomy`). Package-level tools are not reported as unmapped.

## Outputs

* `package_metrics.csv`, `confusion_matrices.csv`: TP, FP, TN, FN, precision, recall, F1, FPR, FNR, accuracy, evaluated and unknown counts. `analysis` is `primary`, `deduplicated` or `including_excluded`. Undefined values are `NA`, never 0. F1 is 2TP/(2TP+FP+FN).
* `bootstrap_intervals.csv`: percentile 95% intervals, `n_valid` replicates, `degenerate_interval` flag.
* `behavior_coverage.csv`: per behavior and behavior-reporting signal plus `union`: `n_confirmed_positive`, `n_unknown_annotation`, `n_evaluated`, `n_detected`, `n_missed`, `detection_rate`, `status` (`ok`, `low_sample`, `very_low_sample`, `N/A`, `no_evaluable_instances`). Thresholds are in `behavior_coverage` config (10 and 3).
* `pairwise_complementarity.csv`: individual and union recall, FPR, precision, F1; recall gain; FPR increase; Jaccard of positive sets; unique and shared TP and FP counts.
* `duplicate_sensitivity.csv`: composition, behavior label counts, package metrics and behavior rates, primary versus deduplicated.
* `unmapped_findings.csv`, `exclusions.csv`, `experiment_manifest.json`, `run_summary.md`, `paper_consistency.csv`.

A stage that cannot run is reported in `experiment_manifest.json` and `run_summary.md` and its file is not written (for example, no `duplicate_sensitivity.csv` without cluster assignments).

## Bootstrap

Default (matches the paper): the unit is a package; each of 2,000 replicates (seed 42, `numpy.random.default_rng`) draws N packages with replacement from all N included packages, not stratified by label. One draw is used for every metric and signal in a replicate. A metric with a zero denominator in a replicate is omitted for that metric and `n_valid` shows how many replicates remain. Intervals are the 2.5th and 97.5th percentiles (linear interpolation). A cluster variant (`method=cluster`) resamples duplicate clusters instead of packages and is a separate sensitivity analysis. The intervals describe resampling variability only; they do not correct selection bias, label error or incomplete ground truth, and a zero-width interval (such as 0 false positives out of 103) is not evidence of zero uncertainty.

## Duplicate sensitivity

Clusters come from the manifest `duplicate_cluster` column, or can be generated offline with `python -m package_analysis cluster --artifacts-dir DIR --output clusters.csv` (normalized-code hash; procedure in `deduplication.py`). Within a cluster the smallest `package_id` is kept. Benign packages are kept as is unless `deduplication.cluster_benign` is true. The retained IDs are written to `duplicate_removed_ids.csv` (the removed ones). Package names are never used as duplicate evidence. Deduplication changes class balance, so precision and F1 shift even when a detector does not change.

## What is and is not reproduced

`data/real/` is a conversion of the outputs of this project's own earlier pipeline (GuardDog 3.2.0, Bandit, offline OSV matchers, a rule-based annotator) with the same seed 42. Run on it, the pipeline reproduces every confusion matrix, point estimate, behavior rate, pair union and deduplication count in the paper's tables; six confidence interval endpoints differ by at most 0.007 (see `paper_consistency.csv` and DEVIATIONS.md). This is a reproduction from the authors' own derived files, not an independent replication: the raw tool outputs, the DataDog sample list and the annotation files used for the paper itself are not part of this package. Tool execution timestamps and per-run versions were not captured and appear as `not_recorded_in_inputs`.

## Security boundaries

The engine reads CSV and YAML only. `cluster` reads `.py` files as text. Nothing is installed, imported or executed, and the tests need no malware samples or network. `data/real/findings.csv` contains short, token-masked excerpts of code that GuardDog flagged in malicious packages; treat it as text, do not paste it into a shell. A live tool-execution adapter is deliberately not included; if you add one, run it in an isolated VM or container with no credentials, no outbound network except what the scan needs, resource limits and manual approval, and keep it separate from this package.

## Known limitations

Single rule-based annotator, no second reviewer, no kappa. The malicious set was largely discovered with GuardDog. The benign set is hand-picked. Static analysis only; no OpenSSF Package Analysis results. Low denominators for B2, B10, B11, B12. Bandit evidence in `data/real` is an aggregate per package because rule ids were not retained. Results describe this benchmark and are not ecosystem-wide estimates.

## Suggested next experiments

Second annotator and Cohen's kappa on a stratified subset; re-run Bandit and GuardDog with raw outputs retained; add OpenSSF dynamic results through the same `tool_runs`/`findings` schema; the paired capability-versus-chain experiment described in METHODOLOGY_AUDIT.md (Extension B).
