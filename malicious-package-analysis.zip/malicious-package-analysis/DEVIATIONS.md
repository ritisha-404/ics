# Deviations from the paper

Labels: **Faithful implementation**, **Clarification**, **Correction**, **Extension**, **Blocked**. "Impact" says how it affects comparability with the paper.

| # | Status | Item | Rationale | Impact on comparability |
|---|---|---|---|---|
| 1 | Faithful | Metrics eq. 1 to 4, behavior rate eq. 5, union rate eq. 6, gain eq. 7, Jaccard eq. 8, percentile bootstrap eq. 9 (2,000 resamples, seed 42). | Direct. | None. |
| 2 | Clarification | Zero-denominator policy: undefined metrics are `NA`, never 0; F1 = 2TP/(2TP+FP+FN). | Paper is silent. With this form F1 is 0 (not NA) when TP = 0 but errors exist, which matches the paper's OSV-Scanner row (precision 0.000, F1 0.000). | None on reported values. |
| 3 | Clarification | Bootstrap unit and scheme: package, unstratified, shared draw across metrics and signals, `numpy.random.default_rng(42)`, linear-interpolated percentiles, zero-denominator replicates omitted per metric with `n_valid` reported. | Paper gives seed and count only. | Six CI endpoints differ from the paper by 0.004 to 0.007; point estimates identical. |
| 4 | Clarification | Signals vs tools: five signals from four tools. `guarddog` counts only threat-category findings; `guarddog_capability` counts any finding. Package verdict is derived from `tool_runs` plus `findings`, and `unknown` is distinct from `not_flagged`. | Preserves the paper's package-level vs behavior-level distinction. | None. |
| 5 | Clarification | Behavior evidence categories are configured per signal; Bandit applicability is B4, B6, B7, B8 and GuardDog applicability is all twelve, both stored in `behavior_mapping.yaml`. Feed, vulnerability and capability signals have no behavior evidence. | Paper states the rule; this makes it reviewable. | None. |
| 6 | Clarification | Annotation statuses: `confirmed_positive`, `confirmed_negative`, `unknown`, `capability_only`; missing row = unannotated. Only `confirmed_positive` is a scored instance. | Paper's "labeled behavior instances" made explicit; never reads absence as negative. | None on reported rates. |
| 7 | Clarification | Pairwise analyses use packages for which both signals have a usable verdict; the vulnerability control and capability output are excluded from pairs by config (`include_in_pairs`). | Paper reports three pairs only. | Same three pairs reproduced. |
| 8 | Clarification | Duplicate representative = smallest `package_id` per malicious cluster; benign packages not clustered. | Paper does not state the rule; counts are rule independent (74 and 103), per-package results may differ with another rule. | Counts match; per-behavior dedup numerators match on the reproduced data. |
| 9 | Extension | Cluster-aware bootstrap (`method=cluster`). | Audit item 4. | Separate rows; never replaces the default. |
| 10 | Extension | Exclusion sensitivity (`analysis=including_excluded`). | Audit item 3. | Separate rows. |
| 11 | Extension | Paper consistency checks (`paper_consistency.csv`): internal arithmetic always, recomputed-vs-reported only for real data in full mode. | Spec item 9. | None. |
| 12 | Extension | `unmapped_findings.csv` with reasons; `exclusions.csv`; `experiment_manifest.json`. | Spec items 2, 3, 8. | None. |
| 13 | Correction | None required. No arithmetic error was found in Tables II and III. The only discrepancies are CI endpoint differences (item 3) and terminology notes (audit items 10 to 12). | Checked in `paper_consistency.csv`. | n/a |
| 14 | Faithful with a data caveat | OSV malicious and OSV-Scanner are represented by custom offline matchers over clones of ossf/malicious-packages and github/advisory-database in `data/real`. They are not the OSV-Scanner binary. The engine itself is source agnostic. | The original run's raw output is unavailable here. | Names follow the paper; provenance records `custom_offline_matcher_*` as the tool version. |
| 15 | Blocked | Bandit rule-level evidence in `data/real` (only per-package aggregate behaviors were retained). | Raw Bandit output is not available. | Behavior rates for Bandit reproduce but cannot be audited rule by rule. |
| 16 | Blocked | Second annotator, kappa, OpenSSF dynamic results, repeated runs for drift, tool execution timestamps. | Not obtainable in this session. | Listed as limitations. |
| 17 | Blocked | Exact reproduction from the PDF alone. | The paper does not ship its manifest, labels, tool outputs or cluster ids. What was reproduced is the earlier pipeline's derived data, which agrees with the paper. | See README "What is and is not reproduced". |
