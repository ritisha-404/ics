# Run summary

Experiment: `blind-spots-pypi-2026`  |  mode: full  |  data: real  |  run (UTC): 2026-10-13T17:29:30+00:00

Included packages: 225 (122 malicious, 103 benign); excluded: 8. Bootstrap: 2000 resamples, seed 42, unit = package.

## Stage status

- behavior_coverage: completed
- bootstrap_package: completed
- duplicate_sensitivity: completed
- exclusion_sensitivity: completed
- package_metrics: completed
- pairwise_complementarity: completed
- paper_consistency: completed (internal arithmetic + comparison with recomputed values)
- validate: completed

## Package-level metrics (primary)



| Signal | Type | Precision | Recall (95% CI) | F1 | FPR (95% CI) | TP | FP | TN | FN | Unknown |
|---|---|---|---|---|---|---|---|---|---|---|
| guarddog | static_maliciousness_detector | 0.788 | 0.975 (0.944 to 1.000) | 0.872 | 0.311 (0.221 to 0.402) | 119 | 32 | 71 | 3 | 0 |
| bandit | static_code_analysis | 0.606 | 0.844 (0.778 to 0.907) | 0.705 | 0.650 (0.556 to 0.743) | 103 | 67 | 36 | 19 | 0 |
| osv_malicious | package_level_feed_match | 1.000 | 0.779 (0.697 to 0.847) | 0.876 | 0.000 (0.000 to 0.000) | 95 | 0 | 103 | 27 | 0 |
| osv_vulnerability *(negative control)* | vulnerability_negative_control | 0.000 | 0.000 (0.000 to 0.000) | 0.000 | 0.010 (0.000 to 0.032) | 0 | 1 | 102 | 122 | 0 |
| guarddog_capability | capability_rule_output | 0.573 | 1.000 (1.000 to 1.000) | 0.728 | 0.883 (0.819 to 0.944) | 122 | 91 | 12 | 0 | 0 |

## Package-level metrics (deduplicated)

Sensitivity: one representative per duplicate cluster. 

| Signal | Type | Precision | Recall (95% CI) | F1 | FPR (95% CI) | TP | FP | TN | FN | Unknown |
|---|---|---|---|---|---|---|---|---|---|---|
| guarddog | static_maliciousness_detector | 0.689 | 0.959 (0.905 to 1.000) | 0.802 | 0.311 (0.223 to 0.400) | 71 | 32 | 71 | 3 | 0 |
| bandit | static_code_analysis | 0.455 | 0.757 (0.653 to 0.851) | 0.569 | 0.650 (0.552 to 0.740) | 56 | 67 | 36 | 18 | 0 |
| osv_malicious | package_level_feed_match | 1.000 | 0.689 (0.583 to 0.797) | 0.816 | 0.000 (0.000 to 0.000) | 51 | 0 | 103 | 23 | 0 |
| osv_vulnerability *(negative control)* | vulnerability_negative_control | 0.000 | 0.000 (0.000 to 0.000) | 0.000 | 0.010 (0.000 to 0.031) | 0 | 1 | 102 | 74 | 0 |
| guarddog_capability | capability_rule_output | 0.448 | 1.000 (1.000 to 1.000) | 0.619 | 0.883 (0.819 to 0.941) | 74 | 91 | 12 | 0 | 0 |

## Package-level metrics (including_excluded)

Sensitivity: packages excluded for lack of a behavior annotation are scored with their package label. 

| Signal | Type | Precision | Recall (95% CI) | F1 | FPR (95% CI) | TP | FP | TN | FN | Unknown |
|---|---|---|---|---|---|---|---|---|---|---|
| guarddog | static_maliciousness_detector | 0.789 | 0.923 (0.875 to 0.964) | 0.851 | 0.311 (0.223 to 0.402) | 120 | 32 | 71 | 10 | 0 |
| bandit | static_code_analysis | 0.610 | 0.808 (0.739 to 0.872) | 0.695 | 0.650 (0.558 to 0.740) | 105 | 67 | 36 | 25 | 0 |
| osv_malicious | package_level_feed_match | 1.000 | 0.754 (0.680 to 0.827) | 0.860 | 0.000 (0.000 to 0.000) | 98 | 0 | 103 | 32 | 0 |
| osv_vulnerability *(negative control)* | vulnerability_negative_control | 0.000 | 0.000 (0.000 to 0.000) | 0.000 | 0.010 (0.000 to 0.033) | 0 | 1 | 102 | 130 | 0 |
| guarddog_capability | capability_rule_output | 0.581 | 0.969 (0.937 to 0.993) | 0.726 | 0.883 (0.821 to 0.941) | 126 | 91 | 12 | 4 | 0 |

## Behavior-level coverage (primary)

Rates are detected/evaluated labeled instances. N/A = tool not applicable (not zero).

| ID | Behavior | n labeled | bandit | guarddog | union | status |
|---|---|---|---|---|---|---|
| B1 | System/environment discovery | 42 | N/A | 31/42 (0.738) | 31/42 (0.738) | ok |
| B2 | Credential/secret access | 5 | N/A | 2/5 (0.400) | 2/5 (0.400) | low_sample |
| B3 | Sensitive-file collection | 13 | N/A | 7/13 (0.538) | 7/13 (0.538) | ok |
| B4 | Command/process execution | 79 | 78/79 (0.987) | 53/79 (0.671) | 79/79 (1.000) | ok |
| B5 | Payload download | 62 | N/A | 56/62 (0.903) | 56/62 (0.903) | ok |
| B6 | Payload execution | 22 | 12/22 (0.545) | 7/22 (0.318) | 14/22 (0.636) | ok |
| B7 | Encoding/obfuscation | 71 | 5/71 (0.070) | 53/71 (0.746) | 58/71 (0.817) | ok |
| B8 | Network communication | 55 | 24/55 (0.436) | 41/55 (0.745) | 44/55 (0.800) | ok |
| B9 | Data exfiltration | 43 | N/A | 36/43 (0.837) | 36/43 (0.837) | ok |
| B10 | Persistence | 2 | N/A | 0/2 (0.000) | 0/2 (0.000) | very_low_sample |
| B11 | Dependency manipulation | 7 | N/A | 0/7 (0.000) | 0/7 (0.000) | low_sample |
| B12 | Evasion/environment gating | 1 | N/A | 0/1 (0.000) | 0/1 (0.000) | very_low_sample |

## Pairwise complementarity (primary)

Read recall gain together with the false-positive increase. A higher union recall is not automatically a better detector.

| A | B | Recall A | Recall B | Union recall | Gain | FPR A | FPR B | Union FPR | Jaccard | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| guarddog | bandit | 0.975 | 0.844 | 1.000 | 0.025 | 0.311 | 0.650 | 0.670 | 0.681 | ok |
| guarddog | osv_malicious | 0.975 | 0.779 | 1.000 | 0.025 | 0.311 | 0.000 | 0.311 | 0.597 | ok |
| bandit | osv_malicious | 0.844 | 0.779 | 0.926 | 0.082 | 0.650 | 0.000 | 0.650 | 0.472 | ok |

## Duplicate sensitivity

| Quantity | Primary | Deduplicated | Delta |
|---|---|---|---|
| n_malicious | 122 | 74 | -48 |
| n_benign | 103 | 103 | 0 |
| n_total | 225 | 177 | -48 |
| n_malicious_clusters | 74 | 74 | 0 |

Deduplication changes sample composition. The retained set is not an independent or representative sample.

## Mapping and exclusions

- Behavior-reporting findings with no behavior mapping (kept in unmapped_findings.csv): 88 (no_behavior_in_taxonomy: 88)
- Excluded packages (exclusions.csv): 8
- Paper consistency checks: 141 consistent, 6 minor difference (CI endpoints), 0 inconsistent, 1 not available (paper_consistency.csv)

## Limitations that apply to every number above

- Results describe this curated benchmark only. They are not ecosystem-wide performance estimates.
- The malicious set was largely discovered with GuardDog, which can inflate GuardDog's apparent recall.
- The benign set is hand-selected, so precision and FPR are conditional on it.
- Bootstrap intervals capture resampling variability only, not selection bias, label error or incomplete ground truth.
- Behavior labels come from the supplied annotations; absent annotations are not negatives, and a missed static finding does not show a behavior is absent.
- A capability finding is not evidence of malicious intent. This run does not test whether chain-aware detection reduces false positives.
