# Data

* `*.example.csv`: copies of the SYNTHETIC test fixture (every row has `data_origin=synthetic`). For learning the schemas only; never enter paper-reproduction results (`allow_synthetic: false`).
* `real/`: conversion of this project's earlier pipeline outputs into the package_analysis schemas (`scripts/convert_prior_pipeline.py`). 233 manifest rows (130 DataDog malicious candidates, 8 excluded for no assignable behavior, 103 benign), 932 tool runs, 1,278 findings, 948 annotations. Limitations: Bandit appears as one aggregate finding per flagged package (`adapter_behaviors`, rule ids not retained); OSV matchers are custom offline matchers over clones of ossf/malicious-packages and github/advisory-database, not the OSV-Scanner binary; execution timestamps are empty; tool versions are the installed versions, not captured per run.

## Preparing your own data

1. One manifest row per evaluated artifact with a stable `package_id`, the true `label`, `sha256` of the exact artifact when you have it, and `duplicate_cluster` if known.
2. One `tool_runs` row per package and tool, including failures (`run_status=failed`). Do not omit failed runs; absence becomes `unknown`, never a negative.
3. One `findings` row per raw finding with the tool's own `rule_id`. Put rule to behavior decisions in `config/behavior_mapping.yaml`, not in the data.
4. `behavior_labels` only for annotations a person or documented procedure actually made.
5. Point `inputs:` in a copy of `config/experiment.yaml` at the new files, set `data_origin` honestly, and run `validate` first.
